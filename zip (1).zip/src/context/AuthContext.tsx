import React, { createContext, useContext, useEffect, useState } from 'react';
import { auth, db } from '../firebase';
import { onAuthStateChanged, User, GoogleAuthProvider, FacebookAuthProvider, signInWithPopup, signInWithRedirect, getRedirectResult, signOut } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithFacebook: () => Promise<void>;
  logout: () => Promise<void>;
  loginAsUser: (userInfo: { uid: string; displayName: string; email: string; photoURL?: string }) => Promise<void>;
  authModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [authModalOpen, setAuthModalOpen] = useState(false);

  useEffect(() => {
    // Check if there is already a local customer user saved
    const localUserStr = localStorage.getItem('local_customer_user');
    if (localUserStr) {
      try {
        setUser(JSON.parse(localUserStr));
      } catch (e) {
        // Ignore
      }
    }

    // Process redirect results when returning to app
    getRedirectResult(auth)
      .then(async (result) => {
        if (result && result.user) {
          const u = result.user;
          setUser(u);
          localStorage.removeItem('local_customer_user');
          const userRef = doc(db, 'users', u.uid);
          const userSnap = await getDoc(userRef);
          if (!userSnap.exists()) {
            await setDoc(userRef, {
              displayName: u.displayName || u.email?.split('@')[0] || 'User',
              email: u.email,
              photoURL: u.photoURL || '',
              createdAt: new Date().toISOString()
            });
          }
        }
      })
      .catch((error) => {
        console.error("Redirect auth error:", error);
      });

    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      if (u) {
        setUser(u);
        localStorage.removeItem('local_customer_user'); // Clear local session in favor of real firebase auth
        const userRef = doc(db, 'users', u.uid);
        const userSnap = await getDoc(userRef);
        if (!userSnap.exists()) {
          await setDoc(userRef, {
            displayName: u.displayName || u.email?.split('@')[0] || 'User',
            email: u.email,
            photoURL: u.photoURL || '',
            createdAt: new Date().toISOString()
          });
        }
      } else {
        // If Firebase state says logged out, keep local user if they logged in with local fallback
        const savedLocalUserStr = localStorage.getItem('local_customer_user');
        if (savedLocalUserStr) {
          try {
            setUser(JSON.parse(savedLocalUserStr));
          } catch (e) {
            setUser(null);
          }
        } else {
          setUser(null);
        }
      }
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const signInWithGoogle = async () => {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({
      prompt: 'select_account'
    });
    const result = await signInWithPopup(auth, provider);
    if (result.user) {
      setUser(result.user);
    }
  };

  const signInWithFacebook = async () => {
    const provider = new FacebookAuthProvider();
    provider.setCustomParameters({
      display: 'popup'
    });
    const result = await signInWithPopup(auth, provider);
    if (result.user) {
      setUser(result.user);
    }
  };

  const loginAsUser = async (userInfo: { uid: string; displayName: string; email: string; photoURL?: string }) => {
    const customUser = {
      uid: userInfo.uid,
      displayName: userInfo.displayName,
      email: userInfo.email,
      photoURL: userInfo.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
      emailVerified: true
    };
    localStorage.setItem('local_customer_user', JSON.stringify(customUser));
    setUser(customUser as any as User);
    
    try {
      await setDoc(doc(db, 'users', customUser.uid), {
        displayName: customUser.displayName,
        email: customUser.email,
        photoURL: customUser.photoURL,
        createdAt: new Date().toISOString()
      }, { merge: true });
    } catch (e) {
      console.warn("Could not sync custom login user to DB:", e);
    }
  };

  const logout = async () => {
    localStorage.removeItem('local_customer_user');
    setUser(null);
    await signOut(auth).catch(() => {});
  };

  return (
    <AuthContext.Provider value={{ user, loading, signInWithGoogle, signInWithFacebook, logout, loginAsUser, authModalOpen, setAuthModalOpen }}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
