import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  projectId: "gen-lang-client-0499747138",
  appId: "1:821463922843:web:d921797e9646100f87ee3e",
  apiKey: "AIzaSyAxREcFMV2_1zu3q1PrsT3_6zTjJifMFu0",
  authDomain: "gen-lang-client-0499747138.firebaseapp.com",
  messagingSenderId: "821463922843",
  measurementId: ""
};

export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, "ai-studio-f4c6fc4f-ec6c-4dec-b4e2-d2c860423940");
export const auth = getAuth(app);
