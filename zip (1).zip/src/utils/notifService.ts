import { db } from '../firebase';
import { collection, addDoc } from 'firebase/firestore';

export interface NotificationPayload {
  orderId: string;
  userId: string;
  customerName: string;
  phone: string;
  email: string;
  status: string;
}

export async function sendOrderNotifications(payload: NotificationPayload) {
  const { orderId, userId, customerName, phone, email, status } = payload;
  const shortId = orderId ? orderId.slice(0, 8) : 'NEW';

  // Customize SMS content depending on status
  let smsContent = '';
  let emailContent = '';

  const statusUpper = status.toUpperCase();

  if (status === 'pending') {
    smsContent = `[RifateShop] Dear ${customerName}, your Order #${shortId} has been successfully placed! Status: PENDING. Total payment via Cash On Delivery. Thanks for choosing RifateShop!`;
    emailContent = `Dear ${customerName},\n\nThank you for shopping at RifateShop! We have received your order #${shortId}.\n\nOrder Details:\n- Status: Pending Confirmation\n- Phone Number: ${phone}\n- Login Email: ${email}\n\nWe are currently verifying the details and will update you shortly.\n\nBest Regards,\nRifateShop Team`;
  } else if (status === 'confirmed') {
    smsContent = `[RifateShop] High-five ${customerName}! Your Order #${shortId} is now CONFIRMED by our merchant. We will pack it shortly.`;
    emailContent = `Hello ${customerName},\n\nGreat news! Your order #${shortId} has been Confirmed by RifateShop.\n\nOur team is currently selecting and packing your items. You will receive an SMS and Email notification when it prepares for shipment.\n\nThank you for choosing us!`;
  } else if (status === 'to_ship' || status === 'to-ship') {
    smsContent = `[RifateShop] Good news ${customerName}, your Order #${shortId} has been queued for shipping & packing! Courier handover in progress.`;
    emailContent = `Dear ${customerName},\n\nPackage packed successfully! Your order #${shortId} is now marked as "To Ship". It is awaiting courier handover.\n\nPrepare your phone (${phone}) for shipping updates.`;
  } else if (status === 'shipped') {
    smsContent = `[RifateShop] Awesome news! Your Order #${shortId} is SHIPPED and on its way. Delivery partner will call you at ${phone}.`;
    emailContent = `Dear ${customerName},\n\nYour package is on its way! Order #${shortId} has been Shipped with our express logistics partner.\n\nPlease keep your phone (${phone}) turned on.\n\nEnjoy your items!`;
  } else if (status === 'delivered') {
    smsContent = `[RifateShop] Delivered! Dear ${customerName}, your Order #${shortId} has been successfully hand-delivered. Hope you enjoy the items!`;
    emailContent = `Hello ${customerName},\n\nYour order #${shortId} has been successfully Delivered!\n\nThank you for shopping with RifateShop. We would love to hear your feedback—please log in and leave a review!`;
  } else if (status === 'cancelled') {
    smsContent = `[RifateShop] Dear ${customerName}, your Order #${shortId} has been CANCELLED as requested or due to stock limitations. We apologize for any inconvenience caused!`;
    emailContent = `Dear ${customerName},\n\nWe regret to inform you that your order #${shortId} has been Cancelled.\n\nThis may have occurred due to your self-cancellation request or immediate merchant stock constraints.\n\nIf you have any questions, please reply or contact our customer helpline immediately.\n\nWarm Regards,\nRifateShop Team`;
  } else {
    smsContent = `[RifateShop] Dear ${customerName}, your Order #${shortId} status has been updated to "${statusUpper}".`;
    emailContent = `Dear ${customerName},\n\nYour order #${shortId} has been updated to: ${statusUpper}.\n\nIf you have any questions, please contact our helpline.`;
  }

  // 1. Persist to Firestore as persistent notification records (Durable Real Integration)
  try {
    await addDoc(collection(db, 'notifications'), {
      orderId,
      userId,
      customerName,
      phone,
      email,
      status,
      smsContent,
      emailContent,
      createdAt: new Date().toISOString()
    });
  } catch (err) {
    console.error("Firestore Notification log failed:", err);
  }
}
