import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { X, Mail, Phone, Lock, Sparkles, Check, AlertCircle, ArrowRight, User as UserIcon } from 'lucide-react';
import { auth, db } from '../firebase';
import { RecaptchaVerifier, signInWithPhoneNumber, ConfirmationResult } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';

export default function AuthModal() {
  const { authModalOpen, setAuthModalOpen, signInWithGoogle, signInWithFacebook, loginAsUser } = useAuth();
  const [activeTab, setActiveTab] = useState<'phone' | 'email'>('phone');
  const [socialAuthError, setSocialAuthError] = useState('');
  
  // Phone form states
  const [phoneNumber, setPhoneNumber] = useState('');
  const [formattedPhone, setFormattedPhone] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [otpTimer, setOtpTimer] = useState(60);
  const [phoneError, setPhoneError] = useState('');
  const [loading, setLoading] = useState(false);
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const recaptchaRef = useRef<HTMLDivElement>(null);
  const recaptchaVerifier = useRef<RecaptchaVerifier | null>(null);

  // Email form states
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [emailError, setEmailError] = useState('');

  useEffect(() => {
    if (!authModalOpen) return;
    
    // Initialize Recaptcha only if it doesn't exist
    if (!recaptchaVerifier.current && activeTab === 'phone' && !otpSent) {
      try {
        recaptchaVerifier.current = new RecaptchaVerifier(auth, 'recaptcha-container', {
          size: 'invisible',
          callback: () => {
            // reCAPTCHA solved, allow signInWithPhoneNumber.
          }
        });
      } catch (err) {
        console.error("Recaptcha initialization error:", err);
      }
    }

    return () => {
      if (recaptchaVerifier.current) {
        recaptchaVerifier.current.clear();
        recaptchaVerifier.current = null;
      }
    };
  }, [authModalOpen, activeTab, otpSent]);

  if (!authModalOpen) return null;

  // Simulate OTP countdown timer
  const startOtpTimer = () => {
    setOtpTimer(60);
    const interval = setInterval(() => {
      setOtpTimer(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    let cleanPhone = phoneNumber.trim().replace(/\D/g, '');
    
    // Bangladesh number handling: if it starts with 0, strip it (it becomes 10 digits)
    if (cleanPhone.startsWith('0')) {
      cleanPhone = cleanPhone.substring(1);
    }
    
    if (!cleanPhone || cleanPhone.length !== 10) {
      setPhoneError('Please enter a valid 11-digit mobile number (e.g., 017XXXXXXXX)');
      return;
    }
    
    setLoading(true);
    setPhoneError('');

    try {
      if (!recaptchaVerifier.current) {
        recaptchaVerifier.current = new RecaptchaVerifier(auth, 'recaptcha-container', {
          size: 'invisible'
        });
      }

      const finalNumber = `+880${cleanPhone}`;
      setFormattedPhone(finalNumber);
      const confirmation = await signInWithPhoneNumber(auth, finalNumber, recaptchaVerifier.current);
      setConfirmationResult(confirmation);
      setOtpSent(true);
      startOtpTimer();
    } catch (err: any) {
      console.error("Phone Auth Error Detail:", err);
      const errorCode = err.code || "";
      const errorMessage = err.message || "";
      
      if (errorCode === 'auth/invalid-phone-number') {
        setPhoneError('Invalid phone number format. Please check and try again.');
      } else if (errorCode === 'auth/too-many-requests') {
        setPhoneError('Too many requests from this device. Please try again later.');
      } else if (errorCode === 'auth/unauthorized-domain') {
        setPhoneError('Unauthorized Domain: Please add this URL to your Firebase Authorized Domains list.');
      } else if (errorMessage.includes('network-error')) {
        setPhoneError('Network error. Please check your internet connection and try again.');
      } else {
        setPhoneError(`OTP sending failed: ${errorCode || 'Error'}. Please try again or use Email Login.`);
      }
      
      // Reset recaptcha on error to allow retry
      if (recaptchaVerifier.current) {
        try {
          recaptchaVerifier.current.clear();
        } catch (e) {}
        recaptchaVerifier.current = null;
      }
    } finally {
      setLoading(false);
    }
  };

  const handleOtpVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpCode || otpCode.length < 6) {
      setPhoneError('Please enter the 6-digit code sent to your mobile');
      return;
    }

    if (!confirmationResult) {
      setPhoneError('Session expired. Please try again.');
      setOtpSent(false);
      return;
    }

    setLoading(true);
    setPhoneError('');

    try {
      const result = await confirmationResult.confirm(otpCode);
      const u = result.user;

      // Sync with Firestore
      const userRef = doc(db, 'users', u.uid);
      const userSnap = await getDoc(userRef);
      
      if (!userSnap.exists()) {
        await setDoc(userRef, {
          displayName: `Customer (${u.phoneNumber})`,
          email: u.email || '',
          photoURL: 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png',
          phoneNumber: u.phoneNumber,
          createdAt: new Date().toISOString()
        });
      }

      setAuthModalOpen(false);
      resetForm();
    } catch (err: any) {
      console.error("OTP Verification Error:", err);
      if (err.code === 'auth/invalid-verification-code') {
        setPhoneError('Invalid verification code. Please try again.');
      } else {
        setPhoneError('Verification failed. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setEmailError('Please fill all required fields');
      return;
    }
    setEmailError('');
    
    // Auto provision custom local active user for fast testing
    await loginAsUser({
      uid: 'email_user_' + Math.floor(Math.random() * 100000),
      displayName: isRegister ? fullName || 'RifateShop Customer' : email.split('@')[0],
      email: email,
      photoURL: 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png'
    });
    setAuthModalOpen(false);
    resetForm();
  };

  const handleTriggerGooglePicker = async () => {
    setSocialAuthError('');
    try {
      await signInWithGoogle();
      setAuthModalOpen(false);
      resetForm();
    } catch (err: any) {
      console.error("Google Authenticator failed:", err);
      setSocialAuthError("গুগল লগইন শুরু করা যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন বা সরাসরি ইমেইল বা ফোন দিয়ে প্রবেশ করুন।");
    }
  };

  const handleTriggerFacebook = async () => {
    setSocialAuthError('');
    try {
      await signInWithFacebook();
      setAuthModalOpen(false);
      resetForm();
    } catch (err: any) {
      console.error("Facebook Authenticator failed:", err);
      setSocialAuthError("ফেসবুক লগইন শুরু করা যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন বা সরাসরি ইমেইল বা ফোন দিয়ে প্রবেশ করুন।");
    }
  };

  const resetForm = () => {
    setPhoneNumber('');
    setOtpSent(false);
    setOtpCode('');
    setPhoneError('');
    setEmail('');
    setPassword('');
    setFullName('');
    setEmailError('');
    setSocialAuthError('');
    setActiveTab('phone');
  };

  return (
    <div className="fixed inset-0 z-55 bg-black/60 flex items-center justify-center p-4 backdrop-blur-xs">
      {/* Outer Card */}
      <div className="bg-white w-full max-w-md rounded-2xl overflow-hidden shadow-2xl border border-slate-100 animate-scale-up relative">
        
        {/* Close Button */}
        <button 
          onClick={() => {
            setAuthModalOpen(false);
            resetForm();
          }} 
          className="absolute right-4 top-4 text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-full transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Branded Section (Daraz / Cartup Vibes) */}
        <div className="bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 p-6 pt-8 text-white text-center">
          <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-3 border border-white/20 shadow-inner">
            <span className="text-3xl font-extrabold tracking-tight">R</span>
          </div>
          <h3 className="text-xl font-bold tracking-tight">Welcome to RifateShop</h3>
          <p className="text-xs text-orange-100 mt-1">Join Bangladesh's premier smart lifestyle shopping hub 🚀</p>
        </div>

        {/* Navigation Tabs (Daraz Style) */}
        <div className="flex border-b border-slate-100 bg-slate-50/50">
          <button 
            onClick={() => { setActiveTab('phone'); setPhoneError(''); }}
            className={`flex-1 py-3 text-sm font-bold border-b-2 flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'phone' 
                ? 'border-orange-500 text-orange-600 bg-white' 
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Phone className="w-4 h-4" />
            Phone Number
          </button>
          <button 
            onClick={() => { setActiveTab('email'); setEmailError(''); }}
            className={`flex-1 py-3 text-sm font-bold border-b-2 flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'email' 
                ? 'border-orange-500 text-orange-600 bg-white' 
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Mail className="w-4 h-4" />
            Email / ID Login
          </button>
        </div>

        {/* Main Form Fields */}
        <div className="p-6">
          {activeTab === 'phone' && (
            <div className="space-y-4">
              {!otpSent ? (
                <form onSubmit={handlePhoneSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                      Mobile Number
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-3.5 text-slate-400 font-bold text-sm border-r border-slate-200 pr-2">+880</span>
                      <input 
                        type="tel"
                        placeholder="1XXXXXXXXX"
                        maxLength={10}
                        value={phoneNumber}
                        onChange={e => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-18 pr-4 text-sm outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-medium"
                      />
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1.5">Enter 10-digit number. E.g: 01967269143</p>
                  </div>

                  {phoneError && (
                    <div className="bg-red-50 text-red-600 rounded-xl p-3 text-xs flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 flex-shrink-0" />
                      <span>{phoneError}</span>
                    </div>
                  )}

                  {/* Phone Auth Loading / Submit State */}
                  <button 
                    type="submit"
                    disabled={loading}
                    className="w-full bg-orange-500 text-white py-3 rounded-xl font-bold hover:bg-orange-600 transition duration-200 shadow-md shadow-orange-500/10 active:scale-98 cursor-pointer text-sm disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {loading ? (
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    ) : null}
                    {loading ? 'Sending...' : 'Send Verification Code'}
                  </button>
                </form>
              ) : (
                <form onSubmit={handleOtpVerify} className="space-y-4">
                  <div>
                    <div className="text-center mb-1">
                      <p className="text-xs text-slate-500">Verification code sent to </p>
                      <p className="text-sm font-bold text-slate-800">{formattedPhone}</p>
                    </div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                      Enter 6-Digit Verification Code (OTP)
                    </label>
                    <input 
                      type="text"
                      maxLength={6}
                      placeholder="XXXXXX"
                      value={otpCode}
                      onChange={e => setOtpCode(e.target.value.replace(/\D/g, ''))}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 text-center text-lg font-bold tracking-widest outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-medium"
                    />
                    <div className="flex justify-between items-center mt-2.5">
                      <button 
                        type="button" 
                        onClick={() => { setOtpSent(false); setOtpCode(''); }}
                        className="text-xs text-slate-500 hover:text-orange-600 underline font-medium"
                      >
                        Change Number
                      </button>
                      {otpTimer > 0 ? (
                        <span className="text-[11px] text-slate-400 font-medium">Resend OTP in {otpTimer}s</span>
                      ) : (
                        <button 
                          type="button" 
                          onClick={handlePhoneSubmit}
                          className="text-xs text-orange-600 font-bold hover:underline"
                        >
                          Resend Verification Code
                        </button>
                      )}
                    </div>
                  </div>

                  {phoneError && (
                    <div className="bg-red-50 text-red-600 rounded-xl p-3 text-xs flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 flex-shrink-0" />
                      <span>{phoneError}</span>
                    </div>
                  )}

                  <button 
                    type="submit"
                    disabled={loading}
                    className="w-full bg-orange-500 text-white py-3 rounded-xl font-bold hover:bg-orange-600 transition duration-200 shadow-md shadow-orange-500/10 active:scale-98 cursor-pointer text-sm disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {loading ? (
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    ) : null}
                    {loading ? 'Verifying...' : 'Verify & Login'}
                  </button>
                </form>
              )}
            </div>
          )}

          {activeTab === 'email' && (
            <form onSubmit={handleEmailSubmit} className="space-y-4">
              {isRegister && (
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                    Full Name
                  </label>
                  <div className="relative">
                    <UserIcon className="absolute left-3 top-3.5 text-slate-400 w-4 h-4" />
                    <input 
                      type="text"
                      placeholder="E.g., Rifat Bin Amirul"
                      value={fullName}
                      onChange={e => setFullName(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-10 pr-4 text-sm outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-medium"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3.5 text-slate-400 w-4 h-4" />
                  <input 
                    type="email"
                    placeholder="yourname@gmail.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-10 pr-4 text-sm outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3.5 text-slate-400 w-4 h-4" />
                  <input 
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-10 pr-4 text-sm outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-medium"
                  />
                </div>
              </div>

              {emailError && (
                <div className="bg-red-50 text-red-600 rounded-xl p-3 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{emailError}</span>
                </div>
              )}

              <button 
                type="submit"
                className="w-full bg-orange-500 text-white py-3 rounded-xl font-bold hover:bg-orange-600 transition duration-200 shadow-md shadow-orange-500/10 active:scale-98 cursor-pointer text-sm"
              >
                {isRegister ? 'Register Account' : 'Login Securely'}
              </button>

              <div className="text-center mt-2">
                <button 
                  type="button"
                  onClick={() => setIsRegister(!isRegister)}
                  className="text-xs text-orange-600 hover:text-orange-700 font-bold hover:underline"
                >
                  {isRegister ? 'Already have an account? Log In' : "Don't have an account? Register Now"}
                </button>
              </div>
            </form>
          )}

          {/* Decorative Divider */}
          <div className="relative my-6 text-center">
            <hr className="border-slate-100" />
            <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-white px-3 text-xs text-slate-400 font-semibold uppercase tracking-wider">
              Or Sign In With
            </span>
          </div>

          {/* Elegant Google/Social Authenticator Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <button 
              onClick={handleTriggerGooglePicker}
              className="flex items-center justify-center gap-2 px-4 py-2.5 border border-slate-200 hover:border-blue-200 hover:bg-blue-50/20 rounded-xl text-xs font-bold text-slate-700 transition cursor-pointer"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v3.92h6.6c-.28 1.5-1.13 2.76-2.4 3.61v3h3.87c2.26-2.08 3.67-5.15 3.67-8.46" />
                <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.87-3c-1.08.72-2.45 1.16-4.06 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.1c1.98 3.96 6.07 6.61 10.71 6.61" />
                <path fill="#FBBC05" d="M5.27 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.6H1.29C.47 8.24 0 10.07 0 12s.47 3.76 1.29 5.4l3.98-3.11" />
                <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.43-3.43C17.95 1.19 15.24 0 12 0 7.36 0 3.27 2.65 1.29 6.6l3.98 3.11c.95-2.85 3.6-4.96 6.73-4.96" />
              </svg>
              Google
            </button>
            <button 
              onClick={handleTriggerFacebook}
              className="flex items-center justify-center gap-2 px-4 py-2.5 border border-slate-200 hover:border-sky-200 hover:bg-sky-50/20 rounded-xl text-xs font-bold text-slate-700 transition cursor-pointer"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" fill="#1877F2">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
              </svg>
              Facebook
            </button>
          </div>

          {socialAuthError && (
            <div className="mt-4 bg-amber-50 text-amber-800 border border-amber-200 rounded-xl p-3 text-xs leading-relaxed flex items-start gap-2">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0 text-amber-600" />
              <span>{socialAuthError}</span>
            </div>
          )}

          {/* User Agreement */}
          <p className="text-[10px] text-slate-400 text-center mt-6 leading-relaxed">
            By signing in, you agree to RifateShop's <span className="underline hover:text-orange-500 cursor-pointer">Terms of Service</span> and <span className="underline hover:text-orange-500 cursor-pointer">Privacy Policy</span>.
          </p>
        </div>

        {/* Global Hidden Recaptcha Anchor */}
        <div id="recaptcha-container" className="hidden"></div>
      </div>
    </div>
  );
}
