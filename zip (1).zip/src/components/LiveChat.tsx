import React, { useState, useEffect, useRef } from 'react';
import { MessageCircle, X, Send, PhoneCall, Loader2, Sparkles, AlertCircle, ShoppingBag } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { db } from '../firebase';
import { collection, addDoc, query, where, orderBy, getDocs, limit, serverTimestamp } from 'firebase/firestore';

interface Message {
  sender: 'user' | 'bot';
  text: string;
  time: string;
}

export default function LiveChat() {
  const { user } = useAuth();
  const { currency } = useCart();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'bot',
      text: '🤖 Welcome to RifateShop Live Support! How can I assist you today? 🧡',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputVal, setInputVal] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Listen to custom custom-open-chat events to open the chat window from the header/taskbar
    const handleOpenChat = () => {
      setIsOpen(true);
    };
    window.addEventListener('open-customer-chat', handleOpenChat);
    return () => window.removeEventListener('open-customer-chat', handleOpenChat);
  }, []);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMsg: Message = {
      sender: 'user',
      text: textToSend,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputVal('');
    setLoading(true);

    try {
      // Opt-in: Persist questions to firebase support collection so Rifat can monitor inquiries
      await addDoc(collection(db, 'support_tickets'), {
        userId: user?.uid || 'guest_user',
        userName: user?.displayName || 'Guest Browser',
        userEmail: user?.email || 'guest@rifateshop.com',
        message: textToSend,
        timestamp: serverTimestamp(),
        status: 'open'
      });
    } catch (e) {
      console.warn("Could not save ticket to Firestore:", e);
    }

    // Process replies
    setTimeout(() => {
      let botReply = "Thank you for contacting us! A support representative will get back to you shortly. You can also contact us directly at +8801967269143 for immediate response. 📞";
      const normalized = textToSend.toLowerCase();

      if (normalized.includes('order') || normalized.includes('delivery') || normalized.includes('track') || normalized.includes('delivery charge')) {
        botReply = `Our logistics delivery charges are:\n• Inside Dhaka: ${currency}70 BDT\n• Outside Dhaka: ${currency}130 BDT\n\nDelivery takes 1-3 days depending on location. 🚚💳 Cash on Delivery is 100% available!`;
      } else if (normalized.includes('hello') || normalized.includes('hi') || normalized.includes('hey') || normalized.includes('assalamualaikum')) {
        botReply = `Hello! How may I help you today? Please choose one of our quick options or type your inquiry! 😊`;
      } else if (normalized.includes('fb') || normalized.includes('facebook') || normalized.includes('page') || normalized.includes('contact')) {
        botReply = `You can reach our official Facebook page via facebook.com/rifateshop25 or call/WhatsApp at +8801967269143. We are happy to help! 💬📱`;
      }

      const botMsg: Message = {
        sender: 'bot',
        text: botReply,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, botMsg]);
      setLoading(false);
    }, 700);
  };

  const handleTrackOrder = async () => {
    if (!user) {
      const botMsg: Message = {
        sender: 'bot',
        text: '❌ Please login to your Google account first using the "Login" button on the top taskbar so we can automatically fetch your orders.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, botMsg]);
      return;
    }

    setLoading(true);
    try {
      const q = query(
        collection(db, 'orders'),
        where('customerEmail', '==', user.email),
        orderBy('createdAt', 'desc'),
        limit(1)
      );
      const snap = await getDocs(q);
      
      if (snap.empty) {
        const botMsg: Message = {
          sender: 'bot',
          text: `🔍 We couldn't find any orders placed under your email (${user.email}). Try ordering something first! 🛒`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setMessages(prev => [...prev, botMsg]);
      } else {
        const orderData = snap.docs[0].data();
        const latestStatus = orderData.status?.toUpperCase() || 'PENDING';
        const totalCost = orderData.total;
        const recipientName = orderData.fullName || user.displayName;

        const botMsg: Message = {
          sender: 'bot',
          text: `📦 **Latest Order Found!**\n\n👤 Recipient: **${recipientName}**\n💵 Total bill: **${currency}${totalCost}**\n🔄 Status: **${latestStatus}**\n💳 Method: **${orderData.paymentMethod?.toUpperCase() || 'COD'}**\n\nWe are preparing your items carefully!`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setMessages(prev => [...prev, botMsg]);
      }
    } catch (err: any) {
      console.error(err);
      const botMsg: Message = {
        sender: 'bot',
        text: `Unable to track orders: ${err.message || err}. You can check your "My Account" page to view order lists!`,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, botMsg]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* Floating Action Taskbar Chat Bubble */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
        {isOpen && (
          <div className="w-80 sm:w-96 h-[480px] bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col mb-4 animate-scale-up">
            {/* Header */}
            <div className="bg-gradient-to-r from-orange-500 to-amber-500 text-white px-4 py-3.5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="relative">
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-400 border-2 border-orange-500 rounded-full"></span>
                  <div className="w-9 h-9 bg-white/20 rounded-full flex items-center justify-center font-bold text-sm">
                    🤖
                  </div>
                </div>
                <div>
                  <h4 className="font-bold text-sm leading-tight">RifateShop Virtual Agent</h4>
                  <p className="text-[10px] text-orange-100 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-yellow-300" />
                    Interactive Support • Online
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)} 
                className="p-1 hover:bg-white/10 rounded-full transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Messages body */}
            <div className="flex-1 overflow-y-auto p-4 bg-slate-50 space-y-3 scrollbar-none">
              {messages.map((m, i) => (
                <div 
                  key={i} 
                  className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'} animate-fade-in`}
                >
                  <div className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 text-xs shadow-2xs leading-relaxed whitespace-pre-wrap ${
                    m.sender === 'user' 
                      ? 'bg-blue-600 text-white rounded-br-none' 
                      : 'bg-white border border-slate-200 text-slate-800 rounded-bl-none'
                  }`}>
                    {m.text}
                    <span className={`block text-[9px] mt-1 text-right  ${
                      m.sender === 'user' ? 'text-blue-200' : 'text-slate-400'
                    }`}>
                      {m.time}
                    </span>
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start items-center gap-2 text-slate-400 text-xs py-1">
                  <Loader2 className="w-4 h-4 animate-spin text-orange-500" />
                  <span>Agent is typing...</span>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Quick Interactive Options */}
            <div className="px-3 py-2 bg-slate-100 border-t border-slate-200 flex flex-wrap gap-1.5 justify-center">
              <button 
                onClick={() => handleSendMessage("What is the delivery charge inside/outside Dhaka?")}
                className="text-[10px] font-bold text-slate-700 bg-white hover:bg-orange-50 hover:text-orange-600 transition border border-slate-200 px-2 py-1 rounded"
              >
                💰 Delivery Charges
              </button>
              <button 
                onClick={handleTrackOrder}
                className="text-[10px] font-bold text-slate-700 bg-white hover:bg-orange-50 hover:text-orange-600 transition border border-slate-200 px-2 py-1 rounded flex items-center gap-1"
              >
                <ShoppingBag className="w-3 h-3 text-orange-500" /> Track My Order
              </button>
              <a 
                href="https://wa.me/8801967269143" 
                target="_blank" 
                rel="noreferrer"
                className="text-[10px] font-bold text-slate-700 bg-white hover:bg-orange-50 hover:text-orange-600 transition border border-slate-200 px-2 py-1 rounded flex items-center gap-1"
              >
                🤝 Chat WhatsApp
              </a>
            </div>

            {/* Support Message form */}
            <form 
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage(inputVal);
              }}
              className="p-3 border-t border-slate-200 bg-white flex items-center gap-2"
            >
              <input 
                type="text"
                value={inputVal}
                onChange={e => setInputVal(e.target.value)}
                placeholder="Ask something..."
                className="flex-1 bg-slate-50 border border-slate-200 rounded-full px-4 py-2 text-xs outline-none focus:ring-1 focus:ring-orange-500"
              />
              <button 
                type="submit" 
                disabled={!inputVal.trim()}
                className="bg-orange-500 text-white p-2 rounded-full hover:bg-orange-600 disabled:opacity-40 transition cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}

        <button 
          onClick={() => setIsOpen(!isOpen)}
          className={`bg-gradient-to-r from-orange-500 to-amber-500 text-white p-4 rounded-full shadow-2xl hover:scale-105 active:scale-95 transition-all cursor-pointer flex items-center gap-2 relative ${
            !isOpen ? 'animate-bounce' : ''
          }`}
          style={{ animationDuration: '3s' }}
        >
          <span className="absolute -top-1 -right-1 bg-red-500 w-3 h-3 rounded-full animate-ping"></span>
          <span className="absolute -top-1 -right-1 bg-red-500 w-3 h-3 rounded-full"></span>
          <MessageCircle className="w-6 h-6" />
          <span className="hidden md:inline text-xs font-bold uppercase tracking-wider">Live Chat</span>
        </button>
      </div>
    </>
  );
}
