import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import Home from './pages/Customer/Home';
import ShopPage from './pages/Customer/ShopPage';
import ProductDetail from './pages/Customer/ProductDetail';
import Account from './pages/Customer/Account';
import AdminLogin from './pages/Admin/AdminLogin';
import AdminLayout from './pages/Admin/AdminLayout';
import Dashboard from './pages/Admin/Dashboard';
import AddProduct from './pages/Admin/AddProduct';
import ProductsList from './pages/Admin/ProductsList';
import Customers from './pages/Admin/Customers';
import Categories from './pages/Admin/Categories';
import Settings from './pages/Admin/Settings';
import MainLayout from './pages/Customer/MainLayout';
import CartPage from './pages/Customer/CartPage';

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <BrowserRouter>
          <Routes>
            {/* Customer Routes */}
            <Route path="/" element={<MainLayout />}>
              <Route index element={<Home />} />
              <Route path="shop" element={<ShopPage />} />
              <Route path="product/:id" element={<ProductDetail />} />
              <Route path="cart" element={<CartPage />} />
              <Route path="account" element={
                <RequireAuth>
                  <Account />
                </RequireAuth>
              } />
            </Route>

            {/* Admin Routes */}
            <Route path="/admin/login" element={<AdminLogin />} />
            <Route path="/admin" element={
              <RequireAdmin>
                <AdminLayout />
              </RequireAdmin>
            }>
              <Route index element={<Dashboard />} />
              <Route path="products" element={<ProductsList />} />
              <Route path="products/add" element={<AddProduct />} />
              <Route path="products/edit/:id" element={<AddProduct />} />
              <Route path="customers" element={<Customers />} />
              <Route path="categories" element={<Categories />} />
              <Route path="settings" element={<Settings />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </CartProvider>
    </AuthProvider>
  );
}

function RequireAuth({ children }: { children: React.ReactElement }) {
  const { user } = useAuth();
  if (!user) {
    return <p className="p-8 text-center bg-gray-50 flex-1">Google loging in... <br/><span className="text-sm text-gray-500">Please wait or navigate back.</span></p>;
  }
  return children;
}

function RequireAdmin({ children }: { children: React.ReactElement }) {
  const isAdmin = localStorage.getItem('admin_token') === 'admin_token_secure_123';
  if (!isAdmin) {
    return <Navigate to="/admin/login" />;
  }
  return children;
}
