import React, { useState, useEffect } from 'react';
import { db } from '../../firebase';
import { collection, onSnapshot, doc, getDoc, setDoc, addDoc, serverTimestamp } from 'firebase/firestore';
import { useNavigate, useParams } from 'react-router-dom';
import { Upload, ArrowLeft, Trash2 } from 'lucide-react';

export default function AddProduct() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [categories, setCategories] = useState<any[]>([]);
  
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [price, setPrice] = useState('');
  const [specialPrice, setSpecialPrice] = useState('');
  const [quantity, setQuantity] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [image, setImage] = useState<string>('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'categories'), (snapshot) => {
      setCategories(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
    });
    
    if (id) {
      getDoc(doc(db, 'products', id)).then(snap => {
        if (snap.exists()) {
          const d = snap.data();
          setTitle(d.title);
          setDesc(d.description);
          setPrice(d.price.toString());
          if (d.specialPrice) setSpecialPrice(d.specialPrice.toString());
          setQuantity(d.quantity ? d.quantity.toString() : '0');
          setCategoryId(d.categoryId);
          setImage(d.image);
        }
      });
    }

    return () => unsub();
  }, [id]);

  const onImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const reader = new FileReader();
      reader.onload = (event) => {
        
        // Resize image to save Firestore space
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 800;
          const scaleSize = MAX_WIDTH / img.width;
          canvas.width = MAX_WIDTH;
          canvas.height = img.height * scaleSize;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
          setImage(canvas.toDataURL('image/jpeg', 0.8));
        };
        if (event.target?.result) {
          img.src = event.target.result as string;
        }
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!image) { alert('Please add an image'); return; }
    if (!categoryId) { alert('Please select a category'); return; }
    setLoading(true);

    const productData = {
      title,
      description: desc,
      price: Number(price),
      specialPrice: specialPrice ? Number(specialPrice) : null,
      quantity: Number(quantity),
      categoryId,
      image,
      updatedAt: serverTimestamp(),
      ...(id ? {} : { createdAt: serverTimestamp() })
    };

    if (id) {
      await setDoc(doc(db, 'products', id), productData, { merge: true });
    } else {
      await addDoc(collection(db, 'products'), productData);
    }
    setLoading(false);
    navigate('/admin/products');
  };

  return (
    <div className="max-w-3xl">
      <button onClick={() => navigate('/admin/products')} className="flex items-center text-slate-500 hover:text-blue-600 transition-colors font-medium mb-6">
        <ArrowLeft className="w-5 h-5 mr-2" />
        Back to Products
      </button>
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
        <h2 className="text-2xl font-bold text-slate-900 mb-6">{id ? 'Edit Product' : 'Add Product'}</h2>
        <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-bold text-slate-700 mb-1">Product Title</label>
          <input type="text" value={title} onChange={e => setTitle(e.target.value)} required className="w-full border border-slate-200 bg-slate-50 rounded p-2 outline-none focus:ring-2 focus:ring-blue-500 transition-shadow" />
        </div>
        
        <div className="flex flex-wrap gap-4">
          <div className="flex-1 min-w-[200px]">
            <label className="block text-sm font-bold text-slate-700 mb-1">Regular Price (Taka)</label>
            <input type="number" value={price} onChange={e => setPrice(e.target.value)} required min="0" className="w-full border border-slate-200 bg-slate-50 rounded p-2 outline-none focus:ring-2 focus:ring-blue-500 transition-shadow" />
          </div>
          <div className="flex-1 min-w-[200px]">
            <label className="block text-sm font-bold text-slate-700 mb-1">Special Price (Optional)</label>
            <input type="number" value={specialPrice} onChange={e => setSpecialPrice(e.target.value)} min="0" className="w-full border border-slate-200 bg-slate-50 rounded p-2 outline-none focus:ring-2 focus:ring-blue-500 transition-shadow" />
          </div>
          <div className="flex-1 min-w-[200px]">
            <label className="block text-sm font-bold text-slate-700 mb-1">Quantity</label>
            <input type="number" value={quantity} onChange={e => setQuantity(e.target.value)} required min="0" className="w-full border border-slate-200 bg-slate-50 rounded p-2 outline-none focus:ring-2 focus:ring-blue-500 transition-shadow" />
          </div>
          <div className="flex-1 min-w-[200px]">
            <label className="block text-sm font-bold text-slate-700 mb-1">Category</label>
            <select value={categoryId} onChange={e => setCategoryId(e.target.value)} required className="w-full border border-slate-200 bg-slate-50 rounded p-2 outline-none focus:ring-2 focus:ring-blue-500 transition-shadow">
              <option value="" disabled>Select Category</option>
              {categories.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-bold text-slate-700 mb-1">Description</label>
          <textarea value={desc} onChange={e => setDesc(e.target.value)} required rows={4} className="w-full border border-slate-200 bg-slate-50 rounded p-2 outline-none focus:ring-2 focus:ring-blue-500 transition-shadow"></textarea>
        </div>

        <div>
          <label className="block text-sm font-bold text-slate-700 mb-1">Product Image</label>
          <div className="flex items-start space-x-4">
            <label className="border-2 border-dashed border-slate-300 bg-slate-50 w-32 h-32 flex flex-col items-center justify-center rounded cursor-pointer hover:bg-slate-100 transition-colors">
              <Upload className="w-6 h-6 text-slate-400 mb-2" />
              <span className="text-xs text-slate-500 font-bold uppercase">Upload</span>
              <input type="file" accept="image/*" onChange={onImageChange} className="hidden" />
            </label>
            {image && (
              <div className="relative w-32 h-32 border border-slate-200 bg-slate-50 rounded overflow-hidden p-1">
                <img src={image} alt="Preview" className="w-full h-full object-contain" />
                <button
                  type="button"
                  onClick={() => {
                    console.log("Removing image");
                    setImage('');
                  }}
                  className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>
        </div>

        <button type="submit" disabled={loading} className="bg-blue-600 text-white px-6 py-2 rounded-md font-bold uppercase text-sm tracking-wide hover:bg-blue-700 disabled:opacity-50 transition-colors">
          {loading ? 'Saving...' : 'Save Product'}
        </button>
      </form>
      </div>
    </div>
  );
}
