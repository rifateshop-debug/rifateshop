import React, { useState, useEffect } from 'react';
import { db } from '../../firebase';
import { collection, onSnapshot, query, orderBy, deleteDoc, doc } from 'firebase/firestore';
import { User, Calendar, Mail, Phone, ExternalLink, Trash2 } from 'lucide-react';

export default function Customers() {
  const [users, setUsers] = useState<any[]>([]);

  useEffect(() => {
    // Sort by createdAt descending to show "nuton jara login" (those who logged in newly)
    const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(q, (snapshot) => {
      setUsers(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
    });
    return () => unsub();
  }, []);

  const handleDelete = async (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to remove ${name}'s login record?`)) {
      try {
        await deleteDoc(doc(db, 'users', id));
      } catch (err) {
        console.error("Error deleting user:", err);
        alert("Failed to delete user record.");
      }
    }
  };

  const formatDate = (dateStr: string) => {
    try {
      return new Date(dateStr).toLocaleString('en-BD', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-3">
          <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
            <User className="w-6 h-6" />
          </div>
          User Logins
        </h2>
        <div className="bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-sm">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Users</span>
          <p className="text-xl font-black text-blue-600">{users.length}</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {users.map(u => (
          <div key={u.id} className="group relative bg-white border border-slate-200 rounded-2xl p-5 hover:shadow-xl hover:shadow-blue-500/5 transition-all duration-300 transform hover:-translate-y-1">
            <div className="flex items-start justify-between mb-4">
              <div className="relative">
                <img 
                  src={u.photoURL || 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png'} 
                  alt={u.displayName} 
                  className="w-14 h-14 rounded-2xl border border-slate-100 p-0.5 bg-white shadow-sm object-cover" 
                />
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
              </div>
              <div className="flex gap-2">
                <div className="p-1.5 bg-slate-50 text-slate-400 border border-slate-100 rounded-md cursor-help" title="View details">
                  <ExternalLink className="w-3.5 h-3.5" />
                </div>
                <button 
                  onClick={() => handleDelete(u.id, u.displayName)}
                  className="p-1.5 bg-red-50 text-red-500 border border-red-100 rounded-md hover:bg-red-500 hover:text-white transition-colors cursor-pointer" 
                  title="Remove Login"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="space-y-1 mb-4">
              <h3 className="font-bold text-slate-900 truncate leading-tight">{u.displayName}</h3>
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <Mail className="w-3 h-3 shrink-0" />
                <span className="truncate">{u.email || 'No email provided'}</span>
              </div>
              {u.phoneNumber && (
                <div className="flex items-center gap-1.5 text-xs text-slate-500">
                  <Phone className="w-3 h-3 shrink-0 text-blue-500" />
                  <span className="font-medium text-slate-700">{u.phoneNumber}</span>
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-orange-500" />
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Joined</span>
              </div>
              <span className="text-[11px] font-medium text-slate-600 bg-slate-50 px-2.5 py-1 rounded-full">
                {formatDate(u.createdAt)}
              </span>
            </div>
          </div>
        ))}
        
        {users.length === 0 && (
          <div className="col-span-full py-20 bg-white border border-dashed border-slate-300 rounded-2xl flex flex-col items-center justify-center space-y-4">
            <div className="p-4 bg-slate-50 rounded-full text-slate-400">
              <User className="w-10 h-10" />
            </div>
            <div className="text-center">
              <p className="text-slate-900 font-bold">No logins detected</p>
              <p className="text-sm text-slate-500">New user logins will appear here in real-time.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
