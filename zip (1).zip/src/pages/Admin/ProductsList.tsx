import React, { useState, useEffect } from 'react';
import { db } from '../../firebase';
import { collection, onSnapshot, deleteDoc, doc } from 'firebase/firestore';
import { Trash2, Edit } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function ProductsList() {
  const [products, setProducts] = useState<any[]>([]);
  const [currency, setCurrency] = useState('৳');

  const [loading, setLoading] = useState<string | null>(null);

  const [deleteTarget, setDeleteTarget] = useState<{ id: string; title: string } | null>(null);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'products'), (snapshot) => {
      setProducts(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'settings', 'shop_config'), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setCurrency(data.currency || '৳');
      }
    });
    return () => unsub();
  }, []);

  const handleDeleteTrigger = (product: any) => {
    setDeleteTarget({ id: product.id, title: product.title || 'Untitled Product' });
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    const { id } = deleteTarget;
    setLoading(id);
    try {
      console.log("Attempting to delete product from FireStore with ID:", id);
      const productDoc = doc(db, 'products', id);
      await deleteDoc(productDoc);
      console.log("Delete successful for:", id);
    } catch (error: any) {
      console.error("Delete failed for ID:", id, "Error detail:", error?.message, error);
      alert("Delete failed: " + (error?.message || error));
    } finally {
      setLoading(null);
      setDeleteTarget(null);
    }
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-slate-900">All Products</h2>
        <Link to="/admin/products/add" className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition uppercase text-sm font-bold tracking-wide">Add New</Link>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="p-3 text-xs font-bold text-slate-500 uppercase tracking-wider">Image</th>
              <th className="p-3 text-xs font-bold text-slate-500 uppercase tracking-wider">Title</th>
              <th className="p-3 text-xs font-bold text-slate-500 uppercase tracking-wider">Price</th>
              <th className="p-3 text-xs font-bold text-slate-500 uppercase tracking-wider">Quantity</th>
              <th className="p-3 text-right text-xs font-bold text-slate-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map(p => (
              <tr key={p.id} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                <td className="p-3">
                  <div className="w-12 h-12 rounded bg-slate-100 flex items-center justify-center p-1 border border-slate-200">
                    <img src={p.image} alt={p.title} className="w-full h-full object-contain" />
                  </div>
                </td>
                <td className="p-3 font-medium text-slate-800">{p.title}</td>
                <td className="p-3">
                  {p.specialPrice ? (
                    <div className="flex flex-col">
                      <span className="font-bold text-blue-600">{currency}{p.specialPrice}</span>
                      <span className="text-xs text-slate-400 line-through">{currency}{p.price}</span>
                    </div>
                  ) : (
                    <span className="font-bold text-blue-600">{currency}{p.price}</span>
                  )}
                </td>
                <td className="p-3 font-medium text-slate-600">{p.quantity || 0}</td>
                <td className="p-3 text-right">
                  <Link to={`/admin/products/edit/${p.id}`} className="inline-block text-blue-600 hover:bg-blue-50 p-2 rounded mr-2 transition-colors">
                    <Edit className="w-4 h-4" />
                  </Link>
                  <button onClick={() => handleDeleteTrigger(p)} disabled={loading === p.id} className="text-red-500 hover:bg-red-50 p-2 rounded transition-colors disabled:opacity-50 cursor-pointer">
                    {loading === p.id ? '...' : <Trash2 className="w-4 h-4" />}
                  </button>
                </td>
              </tr>
            ))}
            {products.length === 0 && (
              <tr>
                <td colSpan={5} className="text-center p-6 text-slate-500">No products found. Add one to see it here.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Sleek Custom Delete Confirmation Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden border border-slate-100 p-6 space-y-4 animate-scale-up">
            <h3 className="text-xl font-bold text-slate-900">Delete Product?</h3>
            <p className="text-sm text-slate-500 leading-normal">
              Are you sure you want to delete <strong className="text-slate-800">"{deleteTarget.title}"</strong>? This action cannot be undone.
            </p>
            <div className="flex gap-3 justify-end pt-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm rounded-lg cursor-pointer transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-sm rounded-lg cursor-pointer transition-colors"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
