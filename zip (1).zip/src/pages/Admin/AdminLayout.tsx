import React, { useState, useEffect } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, PackagePlus, Users, Settings as SettingsIcon, LogOut, Tags, Package, Store } from 'lucide-react';
import { db } from '../../firebase';
import { collection, onSnapshot, query, where } from 'firebase/firestore';

export default function AdminLayout() {
  const navigate = useNavigate();
  const [pendingOrders, setPendingOrders] = useState(0);

  useEffect(() => {
    const q = query(collection(db, 'orders'), where('status', '==', 'pending'));
    const unsub = onSnapshot(q, (snap) => setPendingOrders(snap.docs.length));
    return () => unsub();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('admin_token');
    navigate('/admin/login');
  };

  const navItems = [
    { name: 'Dashboard', path: '/admin', icon: LayoutDashboard },
    { name: 'All Products', path: '/admin/products', icon: Package },
    { name: 'Add Product', path: '/admin/products/add', icon: PackagePlus },
    { name: 'Categories', path: '/admin/categories', icon: Tags },
    { name: 'User Logins', path: '/admin/customers', icon: Users },
    { name: 'Settings', path: '/admin/settings', icon: SettingsIcon },
  ];

  return (
    <div className="flex h-[100vh] bg-slate-50 font-sans text-slate-800 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col shrink-0">
        <div className="p-4 text-xs uppercase tracking-widest text-slate-400 font-bold border-b border-slate-800 flex justify-between items-center">
          <span>Admin Panel</span>
          <NavLink to="/" className="text-blue-400 hover:text-blue-300 flex items-center gap-1 transition-colors" title="Back to Store">
             <Store className="w-4 h-4" />
          </NavLink>
        </div>
        <nav className="flex-1 py-4 flex flex-col">
          {navItems.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              end={item.path === '/admin'}
              className={({ isActive }) =>
                `px-4 py-3 flex items-center gap-3 cursor-pointer transition-colors ${
                  isActive ? 'bg-blue-600 border-l-4 border-blue-400' : 'hover:bg-slate-800 border-l-4 border-transparent text-slate-300'
                }`
              }
            >
              <item.icon className="w-5 h-5" />
              <span className="text-sm font-medium">{item.name}</span>
            </NavLink>
          ))}
          
        </nav>
        
        <div className="p-4 bg-slate-800">
          <div className="text-[10px] text-slate-400 mb-2 font-bold tracking-widest uppercase">Quick Stats</div>
          <div className="flex justify-between text-sm mb-1">
            <span className="text-slate-300">Pending Orders</span>
            <span className="text-yellow-400 font-bold">{pendingOrders}</span>
          </div>
        </div>

        <div className="border-t border-slate-800 p-2">
          <button
            onClick={() => navigate('/')}
            className="w-full mb-1 px-4 py-3 rounded-lg hover:bg-slate-800 flex items-center gap-3 cursor-pointer text-slate-300 transition-colors text-left"
          >
            <Store className="w-5 h-5" />
            <span className="text-sm font-bold uppercase tracking-wider">Storefront</span>
          </button>
          <button
            onClick={handleLogout}
            className="w-full px-4 py-3 rounded-lg hover:bg-red-500/10 hover:text-red-400 flex items-center gap-3 cursor-pointer text-slate-300 transition-colors text-left"
          >
            <LogOut className="w-5 h-5" />
            <span className="text-sm font-bold uppercase tracking-wider">Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto p-6 bg-slate-50 text-slate-800">
        <Outlet />
      </main>
    </div>
  );
}
