import React, { useState, useEffect } from 'react';
import { db } from '../../firebase';
import { collection, onSnapshot, doc, setDoc, deleteDoc } from 'firebase/firestore';
import { Trash2, Upload, Crop as CropIcon } from 'lucide-react';
import ReactCrop, { Crop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';

export default function Settings() {
  const [logo, setLogo] = useState<any>(null);
  const [banners, setBanners] = useState<any[]>([]);
  const [isCropModalOpen, setIsCropModalOpen] = useState(false);
  
  const [upImg, setUpImg] = useState<any>();
  const [crop, setCrop] = useState<Crop>({ unit: '%', width: 50, height: 50, x: 25, y: 25 });
  const [completedCrop, setCompletedCrop] = useState<any>(null);
  const imgRef = React.useRef<HTMLImageElement | null>(null);

  // Bangladeshi Taka and delivery charge controls state
  const [currency, setCurrency] = useState('৳');
  const [insideDhaka, setInsideDhaka] = useState(70);
  const [outsideDhaka, setOutsideDhaka] = useState(130);
  const [savingSettings, setSavingSettings] = useState(false);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'settings'), (snapshot) => {
      const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as any));
      const foundLogo = data.find(d => d.type === 'logo');
      const foundBanners = data.filter(d => d.type === 'banner');
      const foundConfig = data.find(d => d.id === 'shop_config');

      if (foundLogo) setLogo(foundLogo);
      else setLogo(null);
      setBanners(foundBanners);

      if (foundConfig) {
        setCurrency(foundConfig.currency || '৳');
        setInsideDhaka(Number(foundConfig.insideDhaka) ?? 70);
        setOutsideDhaka(Number(foundConfig.outsideDhaka) ?? 130);
      }
    });
    return () => unsub();
  }, []);

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    try {
      await setDoc(doc(db, 'settings', 'shop_config'), {
        currency,
        insideDhaka: Number(insideDhaka),
        outsideDhaka: Number(outsideDhaka),
        updatedAt: new Date().toISOString()
      });
      alert('Taka Currency & delivery rates saved successfully!');
    } catch (err: any) {
      console.error("Save config unsuccessful:", err);
      alert("Error saving settings: " + err.message);
    } finally {
      setSavingSettings(false);
    }
  };

  const onSelectFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const reader = new FileReader();
      reader.addEventListener('load', () => {
        setUpImg(reader.result);
        setIsCropModalOpen(true);
      });
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const saveCroppedImage = async () => {
    if (!completedCrop || !imgRef.current) return;
    const canvas = document.createElement('canvas');
    const image = imgRef.current;
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    canvas.width = completedCrop.width;
    canvas.height = completedCrop.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(
      image,
      completedCrop.x * scaleX,
      completedCrop.y * scaleY,
      completedCrop.width * scaleX,
      completedCrop.height * scaleY,
      0,
      0,
      completedCrop.width,
      completedCrop.height
    );
    
    const base64Image = canvas.toDataURL('image/jpeg', 0.8);
    setIsCropModalOpen(false);
    
    // Save as logo
    await setDoc(doc(db, 'settings', 'main_logo'), {
      type: 'logo',
      url: base64Image,
      createdAt: new Date().toISOString()
    });
  };

  const uploadBanner = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = async () => {
          const canvas = document.createElement('canvas');
          let targetWidth = 820;
          let targetHeight = 360;
          if (img.width < targetWidth && img.width > 0) {
            targetWidth = img.width;
            targetHeight = Math.round(img.width * (360 / 820));
          }
          canvas.width = targetWidth;
          canvas.height = targetHeight;
          
          const imgAspect = img.width / img.height;
          const targetAspect = 820 / 360;
          let sx = 0, sy = 0, sWidth = img.width, sHeight = img.height;
          if (imgAspect > targetAspect) {
             sWidth = img.height * targetAspect;
             sx = (img.width - sWidth) / 2;
          } else {
             sHeight = img.width / targetAspect;
             sy = (img.height - sHeight) / 2;
          }
          
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, sx, sy, sWidth, sHeight, 0, 0, targetWidth, targetHeight);
          const url = canvas.toDataURL('image/jpeg', 0.8);
          
          const newId = Date.now().toString();
          await setDoc(doc(db, 'settings', newId), {
            type: 'banner',
            url,
            createdAt: new Date().toISOString()
          });
        };
        if (event.target?.result) {
          img.src = event.target.result as string;
        }
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const deleteSetting = async (id: string) => {
    await deleteDoc(doc(db, 'settings', id));
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 space-y-8">
      <h2 className="text-2xl font-bold text-slate-900">Site Settings</h2>
      
      {/* Logo Section */}
      <section>
        <h3 className="text-lg font-bold border-b border-slate-100 pb-2 mb-4">Site Logo</h3>
        <div className="flex items-center space-x-6">
          <div className="w-32 h-32 border-2 border-dashed border-slate-300 rounded-xl flex items-center justify-center bg-slate-50 overflow-hidden relative group">
            {logo ? (
              <img src={logo.url} alt="Logo" className="object-contain w-full h-full p-2" />
            ) : (
             <span className="text-slate-400 text-sm font-bold uppercase tracking-widest">No Logo</span>
            )}
          </div>
          <div>
            <label className="bg-blue-600 text-white px-4 py-2 flex items-center space-x-2 rounded-md font-bold uppercase text-sm tracking-wide cursor-pointer hover:bg-blue-700 transition-colors">
              <Upload className="w-4 h-4" />
              <span>{logo ? 'Edit Logo' : 'Upload Logo'}</span>
              <input type="file" accept="image/*" className="hidden" onChange={onSelectFile} />
            </label>
            {logo && (
              <button 
                onClick={() => deleteSetting(logo.id)}
                className="mt-3 text-red-500 text-sm font-bold hover:underline"
              >
                Remove Logo
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Banner Section */}
      <section>
        <div className="flex justify-between items-center border-b border-slate-100 pb-2 mb-4">
          <h3 className="text-lg font-bold">Home Banners</h3>
          <label className="bg-blue-600 text-white px-3 py-1.5 flex items-center space-x-1 rounded-md cursor-pointer hover:bg-blue-700 font-bold uppercase tracking-wide text-xs transition-colors">
            <Upload className="w-4 h-4" />
            <span>Add Banner</span>
            <input type="file" accept="image/*" className="hidden" onChange={uploadBanner} />
          </label>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {banners.map(b => (
            <div key={b.id} className="relative border border-slate-200 rounded-xl overflow-hidden group aspect-[820/360] bg-slate-100">
              <img src={b.url} className="w-full h-full object-cover" alt="Banner" />
              <button 
                onClick={() => deleteSetting(b.id)}
                className="absolute top-2 right-2 bg-red-500 text-white p-2 rounded-full opacity-0 group-hover:opacity-100 transition-all hover:bg-red-600"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
          {banners.length === 0 && <p className="text-slate-500 italic p-4 border border-dashed rounded-xl col-span-full">No banners added.</p>}
        </div>
      </section>

      {/* Currency & Delivery Configuration Section */}
      <section className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
        <h3 className="text-lg font-black text-slate-800 border-b border-slate-200/60 pb-2 mb-4">
          Bangladeshi Taka (BDT) & Delivery Gateway Settings
        </h3>
        <form onSubmit={handleSaveConfig} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-extrabold uppercase tracking-widest text-slate-500 mb-1">
                Shop Currency Symbol
              </label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full border border-slate-300 bg-white rounded-lg p-2.5 font-bold outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              >
                <option value="৳">৳ (Bangladeshi Taka - BDT)</option>
                <option value="$">$ (US Dollar - USD)</option>
                <option value="৳ BDT">৳ BDT</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-extrabold uppercase tracking-widest text-slate-500 mb-1">
                Inside Dhaka Delivery Charge
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-slate-400 font-bold">{currency}</span>
                <input
                  type="number"
                  min="0"
                  value={insideDhaka}
                  onChange={(e) => setInsideDhaka(Number(e.target.value))}
                  required
                  className="w-full border border-slate-300 bg-white rounded-lg p-2.5 pl-8 font-bold outline-none focus:ring-2 focus:ring-blue-500 transition-all text-slate-800"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-extrabold uppercase tracking-widest text-slate-500 mb-1">
                Outside Dhaka Delivery Charge
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-slate-400 font-bold">{currency}</span>
                <input
                  type="number"
                  min="0"
                  value={outsideDhaka}
                  onChange={(e) => setOutsideDhaka(Number(e.target.value))}
                  required
                  className="w-full border border-slate-300 bg-white rounded-lg p-2.5 pl-8 font-bold outline-none focus:ring-2 focus:ring-blue-500 transition-all text-slate-800"
                />
              </div>
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              disabled={savingSettings}
              className="bg-slate-900 hover:bg-blue-600 text-white rounded-xl px-5 py-2.5 text-xs font-bold uppercase tracking-wider transition-all cursor-pointer disabled:opacity-50"
            >
              {savingSettings ? 'Saving Settings...' : 'Save Configuration'}
            </button>
          </div>
        </form>
      </section>

      {/* Crop Modal */}
      {isCropModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 z-50 flex justify-center items-center p-4">
          <div className="bg-white p-6 rounded-xl max-w-2xl w-full shadow-2xl">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold flex items-center space-x-2"><CropIcon /><span>Crop Logo</span></h3>
              <button onClick={() => setIsCropModalOpen(false)} className="text-slate-400 hover:text-slate-600 text-2xl transition-colors">&times;</button>
            </div>
            {upImg && (
              <ReactCrop
                crop={crop}
                onChange={c => setCrop(c)}
                onComplete={c => setCompletedCrop(c)}
                aspect={1} 
              >
                <img src={upImg} onLoad={e => imgRef.current = e.currentTarget} style={{ maxHeight: '60vh' }} alt="Upload" />
              </ReactCrop>
            )}
            <div className="mt-6 flex justify-end space-x-3">
              <button onClick={() => setIsCropModalOpen(false)} className="px-4 py-2 border border-slate-200 rounded-md font-bold text-sm tracking-wide hover:bg-slate-50 transition-colors uppercase">Cancel</button>
              <button onClick={saveCroppedImage} className="px-4 py-2 bg-blue-600 text-white rounded-md font-bold text-sm tracking-wide hover:bg-blue-700 transition-colors uppercase">Save Cropped Logo</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
