import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock, ArrowLeft } from 'lucide-react';

export default function AdminLogin() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();

      if (data.success) {
        localStorage.setItem('admin_token', data.token);
        navigate('/admin');
      } else {
        setError(data.error || 'Login failed');
      }
    } catch (err) {
      console.error("Login fetch error:", err);
      setError('Invalid credentials.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 font-sans text-slate-800 p-4">
      <div className="w-full max-w-sm">
        <button onClick={() => navigate('/')} className="flex items-center text-slate-500 hover:text-blue-600 transition-colors font-medium mb-6">
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Store
        </button>
        <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-200">
          <div className="flex justify-center mb-6">
            <div className="bg-blue-100 p-3 rounded-full">
              <Lock className="text-blue-600 w-8 h-8" />
            </div>
          </div>
          <h2 className="text-2xl font-bold mb-6 text-center text-slate-900">Admin Login</h2>
          {error && <p className="text-red-500 text-sm mb-4 text-center">{error}</p>}
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Username</label>
              <input 
                type="text" 
                className="w-full border border-slate-200 rounded-md p-2 bg-slate-50 focus:ring-2 focus:ring-blue-500 outline-none transition-shadow"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Password</label>
              <input 
                type="password" 
                className="w-full border border-slate-200 rounded-md p-2 bg-slate-50 focus:ring-2 focus:ring-blue-500 outline-none transition-shadow"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <button 
              type="submit" 
              className="w-full bg-blue-600 text-white font-bold py-2 rounded-md hover:bg-blue-700 transition uppercase text-sm mt-4 tracking-wide"
            >
              Login
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
