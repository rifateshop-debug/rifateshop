import React, { useState, useEffect } from 'react';
import { db } from '../../firebase';
import { collection, onSnapshot, doc, deleteDoc, updateDoc } from 'firebase/firestore';
import { Trash2, Package, Check, Clipboard, CheckCircle, Truck, RefreshCw, ShoppingBag, DollarSign, Clock, XCircle } from 'lucide-react';
import { sendOrderNotifications } from '../../utils/notifService';

type OrderStatus = 'all' | 'pending' | 'confirmed' | 'to_ship' | 'shipped' | 'delivered' | 'cancelled';

export default function Dashboard() {
  const [orders, setOrders] = useState<any[]>([]);
  const [deleteOrderTarget, setDeleteOrderTarget] = useState<string | null>(null);
  const [selectedTab, setSelectedTab] = useState<OrderStatus>('all');
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [currency, setCurrency] = useState('৳');

  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'settings', 'shop_config'), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setCurrency(data.currency || '৳');
      }
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'orders'), (snapshot) => {
      const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as any));
      // Sort: newest first
      data.sort((a, b) => {
        const dateA = a.createdAt?.toMillis ? a.createdAt.toMillis() : new Date(a.createdAt || 0).getTime();
        const dateB = b.createdAt?.toMillis ? b.createdAt.toMillis() : new Date(b.createdAt || 0).getTime();
        return dateB - dateA;
      });
      setOrders(data);
    });
    return () => unsub();
  }, []);

  const handleRemoveClick = (id: string) => {
    setDeleteOrderTarget(id);
  };

  const handleConfirmDeleteOrder = async () => {
    if (!deleteOrderTarget) return;
    try {
      await deleteDoc(doc(db, 'orders', deleteOrderTarget));
    } catch (e) {
      console.error("Order delete failed", e);
    } finally {
      setDeleteOrderTarget(null);
    }
  };

  // Move order step by step
  const handleAdvanceStatus = async (order: any) => {
    const current = order.status || 'pending';
    let nextStatus = '';

    if (current === 'pending') nextStatus = 'confirmed';
    else if (current === 'confirmed') nextStatus = 'to_ship';
    else if (current === 'to_ship') nextStatus = 'shipped';
    else if (current === 'shipped') nextStatus = 'delivered';

    if (!nextStatus) return;

    setUpdatingId(order.id);
    try {
      const orderRef = doc(db, 'orders', order.id);
      await updateDoc(orderRef, { status: nextStatus });

      // Automatically dispatch real-time SMS & Email notices matching this progress stage
      await sendOrderNotifications({
        orderId: order.id,
        userId: order.userId || '',
        customerName: order.address?.customerName || 'Valuable Customer',
        phone: order.address?.phone || '',
        email: order.customerEmail || 'customer@rifateshop.com',
        status: nextStatus
      });
    } catch (err) {
      console.error("Error advancing order status:", err);
    } finally {
      setUpdatingId(null);
    }
  };

  // Directly set status to any custom value (Manual Override option if they click dropdown)
  const handleManualStatusChange = async (order: any, nextStatus: string) => {
    if (!nextStatus || nextStatus === order.status) return;

    setUpdatingId(order.id);
    try {
      const orderRef = doc(db, 'orders', order.id);
      await updateDoc(orderRef, { status: nextStatus });

      await sendOrderNotifications({
        orderId: order.id,
        userId: order.userId || '',
        customerName: order.address?.customerName || 'Valuable Customer',
        phone: order.address?.phone || '',
        email: order.customerEmail || 'customer@rifateshop.com',
        status: nextStatus
      });
    } catch (err) {
      console.error("Error updating manual status:", err);
    } finally {
      setUpdatingId(null);
    }
  };

  // Helper stats counts
  const countByStatus = (status: OrderStatus) => {
    if (status === 'all') return orders.length;
    return orders.filter(o => {
      const s = o.status || 'pending';
      if (status === 'to_ship') return s === 'to_ship' || s === 'to-ship';
      return s === status;
    }).length;
  };

  // Calculate sum of active earnings (only Delivered or Confirmed orders count towards revenue)
  const totalRevenue = orders
    .filter(o => o.status === 'delivered')
    .reduce((sum, o) => sum + (Number(o.total) || 0), 0);

  // Filter list by selected Tab
  const filteredOrders = orders.filter(o => {
    if (selectedTab === 'all') return true;
    const s = o.status || 'pending';
    if (selectedTab === 'to_ship') {
      return s === 'to_ship' || s === 'to-ship';
    }
    return s === selectedTab;
  });

  // Color mappings for badges
  const getBadgeStyles = (status: string) => {
    const s = status?.toLowerCase() || '';
    if (s === 'pending') return 'bg-orange-100 text-orange-700 border-orange-200';
    if (s === 'confirmed') return 'bg-blue-100 text-blue-700 border-blue-200';
    if (s === 'to_ship' || s === 'to-ship') return 'bg-indigo-100 text-indigo-700 border-indigo-200';
    if (s === 'shipped') return 'bg-purple-100 text-purple-700 border-purple-200';
    if (s === 'delivered') return 'bg-emerald-100 text-emerald-700 border-emerald-200';
    if (s === 'cancelled') return 'bg-red-100 text-red-700 border-red-200';
    return 'bg-slate-100 text-slate-700 border-slate-200';
  };

  return (
    <div className="space-y-6 text-slate-800 animate-fade-in">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight">Order Fulfilment Center</h2>
          <p className="text-xs text-slate-500 font-medium">Manage steps: Pending ➔ Confirmed ➔ To Ship ➔ Shipped ➔ Delivered</p>
        </div>
      </div>

      {/* KPI Stats widgets banner */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 flex items-center gap-4 shadow-2xs">
          <div className="bg-emerald-50 p-3 rounded-lg text-emerald-600 w-12 h-12 flex items-center justify-center">
            <span className="text-2xl font-black leading-none drop-shadow-xs">৳</span>
          </div>
          <div>
            <p className="text-slate-400 text-[10px] font-extrabold uppercase tracking-widest">Revenue (Delivered)</p>
            <p className="text-xl font-extrabold text-slate-900 mt-0.5">{currency}{totalRevenue.toLocaleString()}</p>
          </div>
        </div>
        <div className="bg-white p-5 rounded-xl border border-slate-200 flex items-center gap-4 shadow-2xs">
          <div className="bg-blue-50 p-3 rounded-lg text-blue-600">
            <ShoppingBag className="w-6 h-6" />
          </div>
          <div>
            <p className="text-slate-400 text-[10px] font-extrabold uppercase tracking-widest">Total Volumes</p>
            <p className="text-xl font-extrabold text-slate-900 mt-0.5">{orders.length} orders</p>
          </div>
        </div>
        <div className="bg-white p-5 rounded-xl border border-slate-200 flex items-center gap-4 shadow-2xs">
          <div className="bg-orange-50 p-3 rounded-lg text-orange-600">
            <Clock className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <p className="text-slate-400 text-[10px] font-extrabold uppercase tracking-widest">Pending Verification</p>
            <p className="text-xl font-extrabold text-slate-900 mt-0.5">{countByStatus('pending')}</p>
          </div>
        </div>
        <div className="bg-white p-5 rounded-xl border border-slate-200 flex items-center gap-4 shadow-2xs">
          <div className="bg-purple-50 p-3 rounded-lg text-purple-600">
            <Truck className="w-6 h-6" />
          </div>
          <div>
            <p className="text-slate-400 text-[10px] font-extrabold uppercase tracking-widest">Active Dispatching</p>
            <p className="text-xl font-extrabold text-slate-900 mt-0.5">
              {countByStatus('confirmed') + countByStatus('to_ship') + countByStatus('shipped')}
            </p>
          </div>
        </div>
      </div>

      {/* Main Order Pipeline Workspace */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        
        {/* Dynamic Horizontal Segment Navigation Tabs */}
        <div className="bg-slate-50 border-b border-slate-100 px-4 pt-4 flex flex-wrap gap-1.5">
          {(['all', 'pending', 'confirmed', 'to_ship', 'shipped', 'delivered', 'cancelled'] as OrderStatus[]).map((tab) => {
            const isActive = selectedTab === tab;
            let displayLabel = tab.toUpperCase().replace('_', ' ');
            if (tab === 'to_ship') displayLabel = 'TO SHIP';

            return (
              <button
                key={tab}
                onClick={() => setSelectedTab(tab)}
                className={`px-4 py-2.5 rounded-t-lg font-bold text-xs tracking-wider transition-all cursor-pointer border-t-2 border-x ${
                  isActive 
                    ? 'bg-white border-x-slate-200 border-t-blue-600 text-blue-600 shadow-2xs' 
                    : 'bg-transparent border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                {displayLabel}
                <span className={`ml-2 px-1.5 py-0.5 rounded-full text-[9px] ${
                  isActive ? 'bg-blue-100 text-blue-700' : 'bg-slate-200 text-slate-600'
                }`}>
                  {countByStatus(tab)}
                </span>
              </button>
            );
          })}
        </div>

        {/* Table Workspace */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-200">
                <th className="p-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider w-28">Order ID</th>
                <th className="p-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Customer Contact</th>
                <th className="p-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Items Summary</th>
                <th className="p-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider w-28">Fees</th>
                <th className="p-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider w-32">Status Badge</th>
                <th className="p-4 text-right text-[10px] font-bold text-slate-400 uppercase tracking-wider">Workflow Progression Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredOrders.map(order => {
                const isUpdating = updatingId === order.id;
                const statusValue = order.status || 'pending';

                return (
                  <tr key={order.id} className="hover:bg-slate-50/60 transition-colors">
                    
                    {/* Order ID & Time */}
                    <td className="p-4 align-top">
                      <p className="text-xs text-slate-600 font-mono font-bold">#{order.id.slice(0, 8)}</p>
                      <p className="text-[10px] text-slate-400 mt-1">
                        {order.createdAt?.toMillis 
                          ? new Date(order.createdAt.toMillis()).toLocaleDateString()
                          : 'Recent Placed'
                        }
                      </p>
                    </td>

                    {/* Customer Info */}
                    <td className="p-4 align-top">
                      <p className="font-extrabold text-sm text-slate-900">{order.address?.customerName || 'Anonymous User'}</p>
                      <p className="text-xs text-blue-600 font-bold font-mono mt-0.5">{order.address?.phone || 'No Phone Number'}</p>
                      {order.customerEmail && (
                        <p className="text-[10px] text-slate-400 truncate max-w-[200px]">{order.customerEmail}</p>
                      )}
                      
                      <div className="text-[11px] text-slate-500 mt-1 max-w-[220px] leading-relaxed">
                        {order.address?.addressLine}, {order.address?.upazila}, {order.address?.district}, {order.address?.division}
                        {order.address?.addressType && (
                          <span className="ml-1.5 px-1.5 py-0.5 bg-slate-100 text-[8px] text-slate-500 rounded font-black uppercase">
                            {order.address.addressType}
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Product items loop */}
                    <td className="p-4 align-top">
                      <div className="space-y-1">
                        {order.items?.map((item: any, idx: number) => (
                          <div key={idx} className="flex gap-1.5 text-xs text-slate-700 leading-snug">
                            <span className="font-extrabold text-blue-600 text-right w-5 leading-none shrink-0">{item.quantity}x</span>
                            <span className="truncate max-w-[160px] leading-none" title={item.title}>{item.title}</span>
                          </div>
                        ))}
                      </div>
                    </td>

                    {/* Fees / Special price */}
                    <td className="p-4 align-top">
                      <p className="font-bold text-sm text-slate-900">{currency}{order.total}</p>
                      <p className="text-[10px] text-slate-400 mt-0.5">method: {order.paymentMethod?.toUpperCase() || 'COD'}</p>
                    </td>

                    {/* Status Badge */}
                    <td className="p-4 align-top">
                      <span className={`px-2 py-1 rounded text-[10px] font-black uppercase tracking-wider border ${getBadgeStyles(statusValue)}`}>
                        {statusValue.replace('_', ' ')}
                      </span>
                    </td>

                    {/* Actions and stage advances */}
                    <td className="p-4 text-right align-top space-y-2">
                      <div className="flex flex-col sm:flex-row items-end sm:items-center justify-end gap-2">
                        
                        {/* Interactive Status overrides option */}
                        <select 
                          value={statusValue} 
                          title="Override Status"
                          onChange={(e) => handleManualStatusChange(order, e.target.value)}
                          className="border border-slate-200 text-xs rounded-lg p-1.5 bg-white text-slate-600 cursor-pointer outline-none hover:border-slate-300"
                        >
                          <option value="pending">Set Pending</option>
                          <option value="confirmed">Set Confirmed</option>
                          <option value="to_ship">Set To Ship</option>
                          <option value="shipped">Set Shipped</option>
                          <option value="delivered">Set Delivered</option>
                          <option value="cancelled">Set Cancelled</option>
                        </select>

                        {/* Automatic Phase Transition Step Progression Button */}
                        {statusValue !== 'delivered' && statusValue !== 'cancelled' ? (
                          <div className="flex flex-wrap gap-2 justify-end items-center">
                            {statusValue === 'confirmed' && (
                              <button
                                disabled={isUpdating}
                                onClick={() => {
                                  if (window.confirm("Are you sure you want to cancel this order?")) {
                                    handleManualStatusChange(order, 'cancelled');
                                  }
                                }}
                                className="bg-rose-50 hover:bg-rose-100 hover:text-rose-700 text-rose-600 border border-rose-200/50 cursor-pointer transition-all duration-300 rounded-lg px-3 py-1.5 text-xs font-bold leading-normal shrink-0 flex items-center justify-center gap-1.5"
                                title="Cancel Order"
                              >
                                <XCircle className="w-3.5 h-3.5" /> Cancel Order
                              </button>
                            )}
                            <button
                              disabled={isUpdating}
                              onClick={() => handleAdvanceStatus(order)}
                              className="bg-slate-900 hover:bg-blue-600 text-white hover:shadow-md cursor-pointer transition-all duration-300 rounded-lg px-3.5 py-1.5 text-xs font-bold leading-normal shrink-0 flex items-center justify-center gap-1.5 min-w-[130px] disabled:opacity-40"
                            >
                              {isUpdating ? (
                                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                              ) : statusValue === 'pending' ? (
                                <>
                                  <CheckCircle className="w-3.5 h-3.5" /> Confirm Order
                                </>
                              ) : statusValue === 'confirmed' ? (
                                <>
                                  <Clipboard className="w-3.5 h-3.5" /> Ready for Ship
                                </>
                              ) : statusValue === 'to_ship' || statusValue === 'to-ship' ? (
                                <>
                                  <Truck className="w-3.5 h-3.5" /> Handover Courier
                                </>
                              ) : statusValue === 'shipped' ? (
                                <>
                                  <Check className="w-3.5 h-3.5" /> Complete Delivery
                                </>
                              ) : (
                                'Next Stage'
                              )}
                            </button>
                          </div>
                        ) : statusValue === 'cancelled' ? (
                          <span className="text-rose-500 font-extrabold text-xs flex items-center gap-1 bg-rose-50 px-2.5 py-1.5 rounded-lg border border-rose-100 shadow-2xs">
                            <XCircle className="w-3.5 h-3.5" /> Cancelled
                          </span>
                        ) : (
                          <span className="text-emerald-500 font-extrabold text-xs flex items-center gap-1 bg-emerald-50 px-2.5 py-1.5 rounded-lg border border-emerald-100 shadow-2xs">
                            <Check className="w-3.5 h-3.5" /> Fulfilled
                          </span>
                        )}

                        {/* Force delete option if pending or needed */}
                        <button 
                          onClick={() => handleRemoveClick(order.id)} 
                          title="Delete Order"
                          className="p-2 border border-slate-200 text-red-500 rounded-lg hover:bg-red-50 hover:border-red-200 transition-all cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>

                      </div>

                    </td>

                  </tr>
                );
              })}

              {filteredOrders.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400 font-medium">
                    No orders found matching status tab: <span className="font-bold text-slate-800 uppercase">"{selectedTab.replace('_', ' ')}"</span>.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

      </div>

      {/* Sleek Custom Order Delete Confirmation Modal */}
      {deleteOrderTarget && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden border border-slate-100 p-6 space-y-4 animate-scale-up">
            <h3 className="text-xl font-bold text-slate-900">Delete Order?</h3>
            <p className="text-sm text-slate-500 leading-normal">
              Are you sure you want to delete order <strong className="text-slate-800">#{deleteOrderTarget.slice(0, 8)}</strong>? This action cannot be undone.
            </p>
            <div className="flex gap-3 justify-end pt-2">
              <button
                type="button"
                onClick={() => setDeleteOrderTarget(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm rounded-lg cursor-pointer transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteOrder}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-sm rounded-lg cursor-pointer transition-colors"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
