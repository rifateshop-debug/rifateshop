import React, { useState, useEffect } from 'react';
import { db } from '../../firebase';
import { collection, onSnapshot, addDoc, deleteDoc, doc, serverTimestamp } from 'firebase/firestore';
import { Trash2 } from 'lucide-react';

export default function Categories() {
  const [categories, setCategories] = useState<any[]>([]);
  const [name, setName] = useState('');

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'categories'), (snapshot) => {
      setCategories(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
    });
    return () => unsub();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    await addDoc(collection(db, 'categories'), {
      name,
      createdAt: serverTimestamp()
    });
    setName('');
  };

  const removeCategory = async (id: string) => {
    await deleteDoc(doc(db, 'categories', id));
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 max-w-2xl">
      <h2 className="text-2xl font-bold text-slate-900 mb-6">Categories</h2>
      
      <form onSubmit={handleAdd} className="flex space-x-3 mb-8">
        <input 
          type="text" 
          placeholder="New Category Name" 
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="flex-1 border border-slate-200 bg-slate-50 rounded-md px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 transition-shadow"
          required
        />
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 font-bold uppercase tracking-wide text-sm transition-colors">Add</button>
      </form>

      <ul className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden">
        {categories.map(cat => (
          <li key={cat.id} className="flex justify-between items-center p-3 hover:bg-slate-50 transition-colors">
            <span className="font-medium text-slate-800">{cat.name}</span>
            <button onClick={() => removeCategory(cat.id)} className="text-red-500 p-2 hover:bg-red-50 rounded transition-colors">
              <Trash2 className="w-4 h-4" />
            </button>
          </li>
        ))}
        {categories.length === 0 && <li className="p-4 text-slate-500 text-center text-sm">No categories found.</li>}
      </ul>
    </div>
  );
}
