import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { db } from '../../firebase';
import { doc, getDoc, collection, query, where, limit, getDocs } from 'firebase/firestore';
import { ShoppingCart, ArrowLeft } from 'lucide-react';
import { ProductCard } from './Home';
import { useCart } from '../../context/CartContext';

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState<any>(null);
  const [similar, setSimilar] = useState<any[]>([]);
  const { addToCart: addToCartContext, currency } = useCart();

  useEffect(() => {
    if (!id) return;
    
    // Fetch product
    getDoc(doc(db, 'products', id)).then(async (snap) => {
      if (snap.exists()) {
        const prodData = { id: snap.id, ...snap.data() } as any;
        setProduct(prodData);
        
        // Fetch similar items (same category)
        const q = query(collection(db, 'products'), where('categoryId', '==', prodData.categoryId), limit(10));
        const simSnap = await getDocs(q);
        let simData = simSnap.docs.map(d => ({ id: d.id, ...d.data() } as any)).filter(d => d.id !== prodData.id);
        
        // If not enough similar products in category, fetch random ones to fill
        if (simData.length < 4) {
             const allQ = query(collection(db, 'products'), limit(15));
             const allSnap = await getDocs(allQ);
             const moreData = allSnap.docs.map(d => ({ id: d.id, ...d.data() } as any)).filter(d => d.id !== prodData.id);
             
             for (const item of moreData) {
                 if (!simData.find(d => d.id === item.id)) {
                     simData.push(item);
                 }
                 if (simData.length >= 4) break;
             }
        }
        
        setSimilar(simData.slice(0, 4));
      }
    });
  }, [id]);

  const addToCart = () => {
    addToCartContext(product);
  };

  const buyNow = () => {
    addToCart();
    navigate('/cart');
  };

  if (!product) return <div className="p-12 text-center text-slate-500">Loading product...</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex-1 w-full text-slate-800">
      <button onClick={() => navigate(-1)} className="flex items-center text-slate-500 hover:text-blue-600 transition-colors font-medium mb-6">
        <ArrowLeft className="w-5 h-5 mr-2" />
        Back
      </button>
      <div className="bg-white rounded-xl shadow-sm border p-6 sm:p-10 mb-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Image */}
          <div className="bg-slate-50 rounded-xl p-8 flex items-center justify-center border border-slate-100">
            <img src={product.image} alt={product.title} className="max-w-full max-h-[400px] object-contain" />
          </div>
          
          {/* Details */}
          <div className="flex flex-col">
            <h1 className="text-3xl font-bold text-slate-900 mb-4">{product.title}</h1>
            {product.specialPrice ? (
              <div className="flex items-center gap-4 mb-8">
                <p className="text-blue-600 font-bold text-3xl">{currency}{product.specialPrice}</p>
                <p className="text-slate-400 font-medium text-xl line-through">{currency}{product.price}</p>
              </div>
            ) : (
              <p className="text-blue-600 font-bold text-3xl mb-8">{currency}{product.price}</p>
            )}
            
            <div className="prose text-slate-600 mb-8 whitespace-pre-wrap">
              {product.description}
            </div>
            
            <div className="mt-auto flex gap-4">
              <button 
                onClick={buyNow}
                className="flex-[1.5] bg-orange-500 hover:bg-orange-600 text-white font-bold py-4 px-6 rounded-lg transition-colors text-sm uppercase"
              >
                Buy Now
              </button>
              <button 
                onClick={addToCart}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-6 rounded-lg transition-colors text-sm uppercase flex items-center justify-center gap-2"
              >
                <ShoppingCart className="w-5 h-5" />
                <span>Add to Cart</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Similar Items */}
      {similar.length > 0 && (
        <div>
          <h3 className="text-2xl font-bold tracking-tight text-slate-900 mb-6 border-b border-slate-200 pb-4">Similar Items</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {similar.map(p => (
              <ProductCard key={p.id} product={p} navigate={navigate} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
