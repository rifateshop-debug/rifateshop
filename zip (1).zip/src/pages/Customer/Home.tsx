import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { db } from '../../firebase';
import { collection, onSnapshot, query, limit, orderBy } from 'firebase/firestore';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { 
  ShoppingCart, 
  ShieldCheck, 
  Truck, 
  CreditCard,
  Laptop, 
  Sparkles, 
  Shirt, 
  Home as HomeIcon, 
  Smartphone, 
  Baby, 
  Watch, 
  Activity,
  Layers,
  ShoppingBag,
  Zap,
  TrendingUp,
  Award
} from 'lucide-react';

const getCategoryIcon = (name: string, index: number) => {
  const norm = name.toLowerCase();
  if (norm.includes('tech') || norm.includes('electronic') || norm.includes('computer') || norm.includes('gadget') || norm.includes('wire')) {
    return <Laptop className="w-5 h-5 text-indigo-600 group-hover:text-white transition-colors" />;
  }
  if (norm.includes('phone') || norm.includes('mobile')) {
    return <Smartphone className="w-5 h-5 text-teal-600 group-hover:text-white transition-colors" />;
  }
  if (norm.includes('clothing') || norm.includes('fashion') || norm.includes('shirt') || norm.includes('dress') || norm.includes('pant')) {
    return <Shirt className="w-5 h-5 text-amber-600 group-hover:text-white transition-colors" />;
  }
  if (norm.includes('beauty') || norm.includes('cosmetic') || norm.includes('care') || norm.includes('makeup')) {
    return <Sparkles className="w-5 h-5 text-pink-600 group-hover:text-white transition-colors" />;
  }
  if (norm.includes('home') || norm.includes('kitchen') || norm.includes('decor') || norm.includes('furniture')) {
    return <HomeIcon className="w-5 h-5 text-emerald-600 group-hover:text-white transition-colors" />;
  }
  if (norm.includes('baby') || norm.includes('kid') || norm.includes('toy')) {
    return <Baby className="w-5 h-5 text-orange-600 group-hover:text-white transition-colors" />;
  }
  if (norm.includes('watch') || norm.includes('jewel') || norm.includes('accessory')) {
    return <Watch className="w-5 h-5 text-cyan-600 group-hover:text-white transition-colors" />;
  }
  if (norm.includes('health') || norm.includes('fitness') || norm.includes('sport')) {
    return <Activity className="w-5 h-5 text-rose-600 group-hover:text-white transition-colors" />;
  }
  if (norm.includes('new') || norm.includes('arrival')) {
    return <Zap className="w-5 h-5 text-red-500 group-hover:text-white transition-colors" />;
  }
  if (norm.includes('trending') || norm.includes('featured')) {
    return <TrendingUp className="w-5 h-5 text-purple-600 group-hover:text-white transition-colors" />;
  }
  if (norm.includes('offer') || norm.includes('special')) {
    return <Award className="w-5 h-5 text-amber-500 group-hover:text-white transition-colors" />;
  }
  
  const fallbackIcons = [
    <ShoppingBag className="w-5 h-5 text-blue-600 group-hover:text-white transition-colors" />,
    <Layers className="w-5 h-5 text-indigo-600 group-hover:text-white transition-colors" />,
    <Zap className="w-5 h-5 text-orange-500 group-hover:text-white transition-colors" />,
    <Sparkles className="w-5 h-5 text-teal-500 group-hover:text-white transition-colors" />
  ];
  return fallbackIcons[index % fallbackIcons.length];
};

const getCategoryBg = (index: number) => {
  const bgs = [
    'bg-blue-50 border-blue-100 group-hover:bg-blue-600',
    'bg-indigo-50 border-indigo-100 group-hover:bg-indigo-600',
    'bg-orange-50 border-orange-100 group-hover:bg-orange-600',
    'bg-teal-50 border-teal-100 group-hover:bg-teal-600'
  ];
  return bgs[index % bgs.length];
};

export default function Home() {
  const [banners, setBanners] = useState<string[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [currentBanner, setCurrentBanner] = useState(0);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get('q')?.toLowerCase() || '';

  useEffect(() => {
    // Fetch banners
    const unsubSettings = onSnapshot(collection(db, 'settings'), (snap) => {
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as any));
      const foundBanners = data.filter(d => d.type === 'banner').map(d => d.url as string);
      setBanners(foundBanners);
    });

    // Fetch products
    const unsubProducts = onSnapshot(collection(db, 'products'), (snap) => {
      const loadedProducts = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      // Sort on client side to prevent Firestore index requirements
      loadedProducts.sort((a: any, b: any) => {
        const dateA = a.createdAt?.seconds || a.createdAt ? new Date(a.createdAt?.seconds * 1000 || a.createdAt).getTime() : 0;
        const dateB = b.createdAt?.seconds || b.createdAt ? new Date(b.createdAt?.seconds * 1000 || b.createdAt).getTime() : 0;
        return dateB - dateA;
      });
      setProducts(loadedProducts);
    });

    // Fetch categories
    const unsubCategories = onSnapshot(collection(db, 'categories'), (snap) => {
      setCategories(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    return () => { unsubSettings(); unsubProducts(); unsubCategories(); };
  }, []);

  // Banner rotation
  useEffect(() => {
    if (banners.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentBanner(prev => (prev + 1) % banners.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [banners.length]);

  // Handle filtering
  const filteredProducts = searchQuery
    ? products.filter(p => p.title.toLowerCase().includes(searchQuery))
    : products.slice(0, 8); // Slice 8 popular products to make screen look rich

  // Process categories dynamically: show all custom ones if they exist
  const finalCategories = categories;

  return (
    <div className="w-full flex-1 flex flex-col p-6 gap-8 max-w-7xl mx-auto w-full">
      {/* Banner Section - only show if there is no search query to keep it clean, or always show. Let's always show. */}
      {!searchQuery && (
        <div className="flex flex-col lg:flex-row gap-6 w-full shrink-0">
          <div className="w-full lg:w-2/3 xl:w-3/4 bg-blue-100 rounded-2xl overflow-hidden relative border border-blue-200 shrink-0 aspect-[820/360]">
            <AnimatePresence mode="wait">
              {banners.length > 0 ? (
                <motion.img
                  key={currentBanner}
                  src={banners[currentBanner]}
                  initial={{ opacity: 0, scale: 1.05 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.8 }}
                  className="absolute inset-0 w-full h-full object-cover"
                  alt="Banner"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gray-200 text-gray-500 font-medium">
                  No active banners yet
                </div>
              )}
            </AnimatePresence>
          </div>

          <div className="w-full lg:w-1/3 xl:w-1/4 bg-white rounded-2xl border border-slate-200 p-6 flex flex-col justify-center flex-1 shrink-0 h-full lg:aspect-auto">
            <h2 className="text-2xl font-bold text-slate-800 mb-4">RifateShop</h2>
            <p className="text-slate-600 mb-6 leading-relaxed text-sm">
              Discover the best quality products at unbeatable prices. From daily essentials to exclusive deals, your trusted online destination.
            </p>
            <div className="space-y-4">
              <div className="flex items-center text-sm font-medium text-slate-700">
                <div className="bg-blue-50 p-2 rounded-full mr-3 border border-blue-100">
                  <ShieldCheck className="w-5 h-5 text-blue-600" />
                </div>
                100% Secure Shopping
              </div>
              <div className="flex items-center text-sm font-medium text-slate-700">
                <div className="bg-blue-50 p-2 rounded-full mr-3 border border-blue-100">
                  <Truck className="w-5 h-5 text-blue-600" />
                </div>
                Fast & Delivery Available
              </div>
              <div className="flex items-center text-sm font-medium text-slate-700">
                <div className="bg-blue-50 p-2 rounded-full mr-3 border border-blue-100">
                  <CreditCard className="w-5 h-5 text-blue-600" />
                </div>
                Multiple Currencies
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Category Section */}
      {!searchQuery && (
        <div className="w-full">
          <div className="flex justify-between items-end mb-4">
            <div>
              <h2 className="text-xl font-bold text-slate-800">Shop by Category</h2>
              <p className="text-xs text-slate-400 mt-0.5">Explore our wide selection of categories</p>
            </div>
            <Link to="/shop" className="text-xs font-bold text-blue-600 hover:underline">
              See All
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {finalCategories.map((cat, index) => (
              <Link
                key={cat.id}
                to={cat.isDefault ? `/shop` : `/shop?category=${cat.id}&cname=${encodeURIComponent(cat.name)}`}
                className="bg-white rounded-xl border border-slate-200 p-4 flex items-center gap-4 hover:shadow-md hover:border-blue-300 transition-all cursor-pointer group active:scale-[98%]"
              >
                <div className={`p-3 rounded-xl shrink-0 transition-all border ${getCategoryBg(index)}`}>
                  {getCategoryIcon(cat.name, index)}
                </div>
                <div className="overflow-hidden">
                  <h3 className="font-bold text-slate-800 text-sm group-hover:text-blue-600 transition-colors truncate">
                    {cat.name}
                  </h3>
                  <p className="text-[10px] text-slate-400 mt-0.5 uppercase tracking-wider font-semibold">Browse</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Featured Products / Search Results */}
      <div className="w-full">
        <div className="flex justify-between items-end mb-4">
          <div>
            <h2 className="text-xl font-bold text-slate-800">
              {searchQuery ? `Search Results for "${searchQuery}"` : 'Popular Products'}
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              {searchQuery ? `Filtered items matching your search` : 'Handpicked products high in quality'}
            </p>
          </div>
          {!searchQuery && (
            <Link to="/shop" className="text-xs font-bold text-blue-600 hover:underline">
              View All
            </Link>
          )}
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {filteredProducts.map((p) => (
            <ProductCard key={p.id} product={p} navigate={navigate} />
          ))}
          {filteredProducts.length === 0 && (
            <div className="col-span-full bg-white rounded-xl shadow-sm p-8 border text-center text-slate-500">
              No products available yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Reusable Product Card
export function ProductCard({ product, navigate }: { product: any, navigate: any }) {
  const { addToCart, currency } = useCart();

  const handleAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
  };

  const handleBuy = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
    navigate('/cart');
  };

  return (
    <div 
      onClick={() => navigate(`/product/${product.id}`)}
      className="bg-white rounded-xl shadow-sm p-3 border hover:shadow-md cursor-pointer transition-shadow flex flex-col"
    >
      <div className="h-40 sm:h-48 bg-slate-100 rounded-lg mb-3 flex items-center justify-center text-slate-400 overflow-hidden relative">
        <img src={product.image} alt={product.title} className="w-full h-full object-contain p-2 hover:scale-105 transition-transform duration-300" />
      </div>
      <div className="flex-1 flex flex-col">
        <h4 className="font-bold text-sm mb-1 line-clamp-2 text-slate-800" title={product.title}>{product.title}</h4>
        {product.specialPrice ? (
          <div className="flex items-center gap-2 mb-3 mt-auto">
            <span className="text-blue-600 font-bold">{currency}{product.specialPrice}</span>
            <span className="text-xs text-slate-400 line-through">{currency}{product.price}</span>
          </div>
        ) : (
          <div className="text-blue-600 font-bold mb-3 mt-auto">{currency}{product.price}</div>
        )}
        <div className="flex gap-2">
          <button 
            onClick={handleBuy}
            className="flex-1 bg-orange-500 hover:bg-orange-600 text-white text-[10px] sm:text-xs font-bold py-2 rounded-md uppercase transition-colors"
          >
            Buy Now
          </button>
          <button 
            onClick={handleAdd}
            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-[10px] sm:text-xs font-bold py-2 rounded-md uppercase transition-colors"
          >
            Add Cart
          </button>
        </div>
      </div>
    </div>
  );
}
