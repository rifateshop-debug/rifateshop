import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { db } from '../../firebase';
import { collection, query, where, onSnapshot, doc, updateDoc } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Home as HomeIcon, Briefcase, MapPin, Phone, Edit, Check, Plus, Loader2 } from 'lucide-react';
import { divisionList, getDistricts, getUpazilas } from '../../data/bangladeshLocation';
import { useCart } from '../../context/CartContext';

const getStatusIndex = (status: string) => {
  const s = status?.toLowerCase() || 'pending';
  if (s === 'pending') return 0;
  if (s === 'confirmed') return 1;
  if (s === 'to_ship' || s === 'to-ship') return 2;
  if (s === 'shipped') return 3;
  if (s === 'delivered') return 4;
  return 0;
};

const STEPS = [
  { label: 'Placed', sub: 'Awaiting' },
  { label: 'Confirmed', sub: 'Verified' },
  { label: 'To Ship', sub: 'Packaging' },
  { label: 'Shipped', sub: 'In Transit' },
  { label: 'Delivered', sub: 'Completed' }
];

export default function Account() {
  const { user, logout } = useAuth();
  const { currency } = useCart();
  const [activeTab, setActiveTab] = useState('orders');
  const [orderFilter, setOrderFilter] = useState<'all' | 'pending' | 'confirmed' | 'to_ship' | 'shipped' | 'delivered'>('all');
  const [orders, setOrders] = useState<any[]>([]);
  const [profile, setProfile] = useState<any>(null);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const navigate = useNavigate();

  // Form State for Address
  const [customerName, setCustomerName] = useState('');
  const [division, setDivision] = useState('');
  const [district, setDistrict] = useState('');
  const [upazila, setUpazila] = useState('');
  const [addressLine, setAddressLine] = useState('');
  const [phone, setPhone] = useState('');
  const [addressType, setAddressType] = useState('home'); // 'home' | 'office'

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'orders'), where('userId', '==', user.uid));
    const unsub = onSnapshot(q, (snap) => {
       const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as any));
       data.sort((a,b) => b.createdAt?.toMillis() - a.createdAt?.toMillis());
       setOrders(data);
    });
    return () => unsub();
  }, [user]);

  useEffect(() => {
    if (!user) return;
    const userDocRef = doc(db, 'users', user.uid);
    const unsubProfile = onSnapshot(userDocRef, (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setProfile(data);
        if (data.savedAddress) {
          setCustomerName(data.savedAddress.customerName || '');
          setDivision(data.savedAddress.division || '');
          setDistrict(data.savedAddress.district || '');
          setUpazila(data.savedAddress.upazila || '');
          setAddressLine(data.savedAddress.addressLine || '');
          setPhone(data.savedAddress.phone || '');
          setAddressType(data.savedAddress.addressType || 'home');
        } else {
          setCustomerName(user.displayName || '');
        }
      }
    });
    return () => unsubProfile();
  }, [user]);

  const handleSaveAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSaving(true);
    try {
      const userDocRef = doc(db, 'users', user.uid);
      await updateDoc(userDocRef, {
        savedAddress: {
          customerName,
          division,
          district,
          upazila,
          addressLine,
          phone,
          addressType
        }
      });
      setEditing(false);
    } catch (err) {
      console.error(err);
      alert('Failed to save address. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  if (!user) return null;

  return (
    <div className="max-w-5xl mx-auto px-4 w-full py-12 text-slate-800">
      <button onClick={() => navigate('/')} className="flex items-center text-slate-500 hover:text-blue-600 transition-colors font-medium mb-6 cursor-pointer">
        <ArrowLeft className="w-5 h-5 mr-2" />
        Back to Store
      </button>
      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar */}
      <aside className="w-full md:w-64 bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden h-fit">
        <div className="p-6 text-center border-b border-slate-100">
          {user.photoURL ? (
             <img src={user.photoURL} alt={user.displayName || 'User'} className="w-20 h-20 rounded-full mx-auto mb-3 border border-slate-200 p-1" />
          ) : (
             <div className="w-20 h-20 bg-blue-500 rounded-full mx-auto mb-3 flex items-center justify-center text-white text-3xl font-bold">
                {user.displayName?.[0] || 'U'}
             </div>
          )}
          <h3 className="font-bold text-slate-900">{user.displayName}</h3>
          <p className="text-sm text-slate-500 truncate">{user.email}</p>
        </div>
        <nav className="flex flex-col">
          <button onClick={() => setActiveTab('orders')} className={`px-6 py-3 text-left font-medium hover:bg-slate-50 transition-colors cursor-pointer ${activeTab === 'orders' ? 'text-blue-600 border-l-4 border-blue-600 bg-blue-50/50' : 'text-slate-600 border-l-4 border-transparent'}`}>My Orders</button>
          <button onClick={() => setActiveTab('reviews')} className={`px-6 py-3 text-left font-medium hover:bg-slate-50 transition-colors cursor-pointer ${activeTab === 'reviews' ? 'text-blue-600 border-l-4 border-blue-600 bg-blue-50/50' : 'text-slate-600 border-l-4 border-transparent'}`}>Reviews</button>
          <button onClick={() => setActiveTab('address')} className={`px-6 py-3 text-left font-medium hover:bg-slate-50 transition-colors cursor-pointer ${activeTab === 'address' ? 'text-blue-600 border-l-4 border-blue-600 bg-blue-50/50' : 'text-slate-600 border-l-4 border-transparent'}`}>Saved Address</button>
          <button onClick={logout} className="px-6 py-3 text-left font-medium text-red-500 hover:bg-red-50 border-t border-slate-100 transition-colors cursor-pointer">Log out</button>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 bg-white p-6 md:p-8 rounded-xl shadow-sm border border-slate-200">
        {activeTab === 'orders' && (
          <div>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
              <h2 className="text-2xl font-bold text-slate-900">My Orders</h2>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest bg-slate-50 border border-slate-200 px-2.5 py-1 rounded-md">
                Tracking Pipeline
              </p>
            </div>

            {/* Always visible order track status option tags */}
            <div className="flex flex-wrap gap-1.5 p-1 bg-slate-50 border border-slate-200 rounded-xl mb-6">
              {[
                { key: 'all', count: orders.length, label: 'All Orders' },
                { key: 'pending', count: orders.filter(o => !o.status || o.status === 'pending').length, label: 'Pending' },
                { key: 'confirmed', count: orders.filter(o => o.status === 'confirmed').length, label: 'Confirmed' },
                { key: 'to_ship', count: orders.filter(o => o.status === 'to_ship' || o.status === 'to-ship').length, label: 'To Ship' },
                { key: 'shipped', count: orders.filter(o => o.status === 'shipped').length, label: 'Shipped' },
                { key: 'delivered', count: orders.filter(o => o.status === 'delivered').length, label: 'Delivered' }
              ].map((tab) => {
                const isActive = orderFilter === tab.key;
                return (
                  <button
                    key={tab.key}
                    type="button"
                    onClick={() => setOrderFilter(tab.key as any)}
                    className={`flex-1 min-w-[90px] py-2 px-1 rounded-lg text-[10px] font-bold uppercase tracking-wider cursor-pointer text-center transition-all ${
                      isActive
                        ? 'bg-blue-600 text-white font-extrabold shadow-sm scale-[101%]'
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 font-bold'
                    }`}
                  >
                    <div>{tab.label}</div>
                    <div className={`text-[9px] ${isActive ? 'text-blue-100' : 'text-slate-400'} font-bold mt-0.5`}>
                      ({tab.count})
                    </div>
                  </button>
                );
              })}
            </div>

            {orders.length === 0 ? (
              <div className="space-y-6">
                <div className="text-center py-6 border border-dashed border-slate-200 rounded-xl bg-slate-50/40">
                  <p className="text-slate-500 text-sm font-semibold">You haven't placed any orders yet.</p>
                  <p className="text-[11px] text-slate-400 mt-1">Once placed, find your live status trackers under the stages above!</p>
                </div>

                {/* Always visible static tracking helper guide highlighting Confirmed, To Ship, Shipped, Delivered options */}
                <div className="bg-slate-50 border border-slate-200/60 rounded-2xl p-5">
                  <p className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 mb-3.5 text-center">
                    RifateShop Order Fulfillment Flowchart
                  </p>
                  <div className="relative flex flex-col md:flex-row justify-between items-start md:items-center gap-4 py-2">
                    {/* Connecting Line */}
                    <div className="hidden md:block absolute left-4 right-4 top-[17px] h-0.5 bg-slate-200 z-0" />
                    {STEPS.map((step, idx) => (
                      <div key={idx} className="flex md:flex-col items-center gap-3 md:gap-1.5 flex-1 w-full text-left md:text-center z-10">
                        <div className="w-9 h-9 rounded-full bg-slate-100 border-2 border-slate-200 text-slate-500 flex items-center justify-center font-black text-xs">
                          {idx + 1}
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-700 leading-tight">
                            {step.label}
                          </p>
                          <p className="text-[9px] text-slate-400 leading-none mt-0.5">{step.sub}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : orders.filter(o => {
              if (orderFilter === 'all') return true;
              const s = o.status || 'pending';
              if (orderFilter === 'to_ship') return s === 'to_ship' || s === 'to-ship';
              return s === orderFilter;
            }).length === 0 ? (
              <div className="text-center py-10 border border-dashed border-slate-200 rounded-xl bg-slate-50/40">
                <p className="text-slate-500 text-sm font-semibold">No orders currently under "{orderFilter.toUpperCase().replace('_', ' ')}" stage.</p>
                <p className="text-[11px] text-slate-400 mt-1">Select another stage to view your other orders!</p>
              </div>
            ) : (
              <div className="space-y-4">
                {orders
                  .filter(o => {
                    if (orderFilter === 'all') return true;
                    const s = o.status || 'pending';
                    if (orderFilter === 'to_ship') return s === 'to_ship' || s === 'to-ship';
                    return s === orderFilter;
                  })
                  .map(order => (
                    <div key={order.id} className="border border-slate-200 rounded-lg p-5">
                      <div className="flex justify-between items-center mb-4 pb-3 border-b border-slate-100">
                        <p className="text-sm font-bold text-slate-500 uppercase tracking-wider">Order ID: {order.id}</p>
                        <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded ${order.status === 'delivered' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>
                          {order.status}
                        </span>
                      </div>
                      <div className="space-y-2 mb-4 animate-fade-in">
                         {order.items?.map((item:any, i:number) => (
                            <div key={i} className="flex justify-between text-sm">
                              <span className="text-slate-700">{item.quantity}x {item.title}</span>
                              <span className="font-bold text-slate-900">{currency}{item.specialPrice || item.price}</span>
                            </div>
                         ))}
                      </div>
                      <div className="bg-slate-50 px-4 py-2.5 rounded-lg border border-slate-100 text-xs text-slate-500 space-y-1 mt-3">
                        <p className="font-bold text-slate-700 flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-slate-400" />
                          Delivery Address {order.address?.addressType && (
                            <span className="bg-blue-100 text-blue-700 text-[10px] uppercase font-extrabold px-1.5 py-0.5 rounded-md ml-1.5 gap-1 inline-flex items-center">
                              {order.address.addressType === 'home' ? <HomeIcon className="w-2.5 h-2.5" /> : <Briefcase className="w-2.5 h-2.5" />}
                              {order.address.addressType}
                            </span>
                          )}
                        </p>
                        {order.address?.customerName && (
                          <p className="text-slate-700 font-bold">Name: {order.address.customerName}</p>
                        )}
                        <p>{order.address?.addressLine}, {order.address?.upazila}, {order.address?.district}, {order.address?.division}</p>
                        <p className="flex items-center gap-1 mt-1"><Phone className="w-3 h-3 text-slate-400" /> {order.address?.phone}</p>
                      </div>

                      {/* Progress tracking timeline stepper */}
                      <div className="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-100 mb-2">
                        <p className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 mb-3">Order Progress Tracker</p>
                        <div className="relative flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                          
                          {/* Connecting Line for Web/Desktop */}
                          <div className="hidden md:block absolute left-4 right-4 top-[17px] h-0.5 bg-slate-200 z-0">
                            <div 
                              className="h-full bg-blue-600 transition-all duration-500 rounded"
                              style={{ width: `${(getStatusIndex(order.status) / 4) * 100}%` }}
                            />
                          </div>

                          {STEPS.map((step, idx) => {
                            const currentIdx = getStatusIndex(order.status);
                            const isCompleted = idx <= currentIdx;
                            const isActive = idx === currentIdx;

                            return (
                              <div key={idx} className="flex md:flex-col items-center gap-3 md:gap-1.5 flex-1 w-full text-left md:text-center z-10">
                                <div className={`w-9 h-9 rounded-full flex items-center justify-center font-extrabold text-[11px] transition-all duration-300 ${
                                  isCompleted 
                                    ? 'bg-blue-600 text-white shadow-md ring-4 ring-blue-100 border border-blue-600' 
                                    : 'bg-white text-slate-400 border-2 border-slate-200'
                                }`}>
                                  {isCompleted ? '✓' : idx + 1}
                                </div>
                                <div className="min-w-0">
                                  <p className={`text-xs font-bold leading-tight ${isCompleted ? 'text-blue-700 font-extrabold' : 'text-slate-500'}`}>
                                    {step.label}
                                  </p>
                                  <p className="text-[9px] text-slate-400 leading-none mt-0.5">{step.sub}</p>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      <div className="border-t border-slate-100 pt-3 flex justify-between font-bold text-lg mt-3">
                         <span className="text-slate-900">Total</span>
                         <span className="text-blue-600">{currency}{order.total}</span>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'reviews' && (
          <div>
             <h2 className="text-2xl font-bold mb-6 text-slate-900">My Reviews</h2>
             <p className="text-slate-500">No reviews yet.</p>
          </div>
        )}
        
        {activeTab === 'address' && (
          <div>
             <div className="flex justify-between items-center mb-6">
               <h2 className="text-2xl font-bold text-slate-900">Saved Address</h2>
               {!editing && profile?.savedAddress && (
                 <button 
                   onClick={() => setEditing(true)} 
                   className="inline-flex items-center gap-2 text-sm bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-3 py-1.5 rounded-lg cursor-pointer transition-all active:scale-[97%]"
                 >
                   <Edit className="w-4 h-4" /> Edit Address
                 </button>
               )}
             </div>

             {editing ? (
               <form onSubmit={handleSaveAddress} className="space-y-4 max-w-lg border border-slate-200 rounded-xl p-6 bg-slate-50/50">
                 <h3 className="font-bold text-slate-700 text-sm mb-2">Configure Shipping Info</h3>
                 
                 <div>
                   <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Customer Name</label>
                   <input 
                     required 
                     type="text" 
                     placeholder="Customer Full Name" 
                     value={customerName} 
                     onChange={e => setCustomerName(e.target.value)} 
                     className="w-full border border-slate-200 p-2 rounded text-sm bg-white outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 mb-2" 
                   />
                 </div>

                 <div>
                   <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Delivery Point</label>
                   <div className="grid grid-cols-2 gap-3 mb-2">
                     <button
                       type="button"
                       onClick={() => setAddressType('home')}
                       className={`flex items-center justify-center gap-2 p-3 rounded-lg border-2 font-bold text-sm cursor-pointer transition-all ${
                         addressType === 'home' 
                           ? 'border-blue-600 bg-blue-50 text-blue-700 shadow-sm' 
                           : 'border-slate-200 hover:border-slate-300 bg-white text-slate-600'
                       }`}
                     >
                       <HomeIcon className="w-4 h-4" /> Home
                     </button>
                     <button
                       type="button"
                       onClick={() => setAddressType('office')}
                       className={`flex items-center justify-center gap-2 p-3 rounded-lg border-2 font-bold text-sm cursor-pointer transition-all ${
                         addressType === 'office' 
                           ? 'border-blue-600 bg-blue-50 text-blue-700 shadow-sm' 
                           : 'border-slate-200 hover:border-slate-300 bg-white text-slate-600'
                       }`}
                     >
                       <Briefcase className="w-4 h-4" /> Office
                     </button>
                   </div>
                 </div>

                 <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                   <div>
                     <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Division</label>
                     <select 
                       required 
                       value={division} 
                       onChange={e => {setDivision(e.target.value); setDistrict(''); setUpazila('');}} 
                       className="w-full border border-slate-200 p-2 rounded text-sm bg-white outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                     >
                       <option value="">Select Division</option>
                       {divisionList.map(d => <option key={d} value={d}>{d}</option>)}
                     </select>
                   </div>
                   
                   <div>
                     <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">District</label>
                     <select 
                       required 
                       value={district} 
                       disabled={!division} 
                       onChange={e => {setDistrict(e.target.value); setUpazila('');}} 
                       className="w-full border border-slate-200 p-2 rounded text-sm bg-white outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 disabled:opacity-50"
                     >
                       <option value="">Select District</option>
                       {division && getDistricts(division).map(d => <option key={d} value={d}>{d}</option>)}
                     </select>
                   </div>
                   
                   <div>
                     <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Upazila</label>
                     <select 
                       required 
                       value={upazila} 
                       disabled={!district} 
                       onChange={e => setUpazila(e.target.value)} 
                       className="w-full border border-slate-200 p-2 rounded text-sm bg-white outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 disabled:opacity-50"
                     >
                       <option value="">Select Upazila</option>
                       {division && district && getUpazilas(division, district).map(u => <option key={u} value={u}>{u}</option>)}
                     </select>
                   </div>
                 </div>

                 <div>
                   <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Detailed Address</label>
                   <textarea 
                     required 
                     placeholder="Detailed Address (House, Road, Apartment info)" 
                     value={addressLine} 
                     onChange={e => setAddressLine(e.target.value)} 
                     rows={3} 
                     className="w-full border border-slate-200 p-2 rounded text-sm bg-white outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                   ></textarea>
                 </div>

                 <div>
                   <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Phone Number</label>
                   <input 
                     required 
                     type="tel" 
                     placeholder="Phone Number" 
                     value={phone} 
                     onChange={e => setPhone(e.target.value)} 
                     className="w-full border border-slate-200 p-2 rounded text-sm bg-white outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500" 
                   />
                 </div>

                 <div className="flex gap-3 pt-2">
                   <button 
                     type="button" 
                     onClick={() => setEditing(false)} 
                     className="px-4 py-2 border border-slate-200 bg-white text-slate-600 font-bold text-sm rounded-lg hover:bg-slate-100 cursor-pointer active:scale-[98%] transition-all"
                   >
                     Cancel
                   </button>
                   <button 
                     type="submit" 
                     disabled={saving} 
                     className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-lg cursor-pointer disabled:opacity-50 inline-flex items-center gap-2 active:scale-[98%] transition-all"
                   >
                     {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />} Save Address
                   </button>
                 </div>
               </form>
             ) : profile?.savedAddress ? (
               <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 max-w-lg space-y-4 shadow-xs relative overflow-hidden">
                 {/* Address Tag label */}
                 <div className="absolute right-4 top-4">
                   <span className="bg-blue-100 text-blue-700 text-xs uppercase font-extrabold px-3 py-1 rounded-full gap-1 inline-flex items-center shadow-2xs">
                     {addressType === 'home' ? <HomeIcon className="w-3.5 h-3.5" /> : <Briefcase className="w-3.5 h-3.5" />}
                     {addressType}
                   </span>
                 </div>

                 <div>
                   <p className="text-xs uppercase font-bold text-slate-400 tracking-wider">Customer Name</p>
                   <p className="font-bold text-slate-900 mt-0.5 text-base">
                     {profile.savedAddress.customerName || profile.displayName || user.displayName}
                   </p>
                 </div>

                 <div>
                   <p className="text-xs uppercase font-bold text-slate-400 tracking-wider">Contact Phone</p>
                   <p className="font-bold text-slate-900 mt-0.5 text-base flex items-center gap-2">
                     <Phone className="w-4 h-4 text-blue-600" /> {profile.savedAddress.phone}
                   </p>
                 </div>

                 <div>
                   <p className="text-xs uppercase font-bold text-slate-400 tracking-wider">Delivery Point Address</p>
                   <p className="text-slate-800 font-medium mt-1 leading-relaxed">
                     {profile.savedAddress.addressLine}
                   </p>
                   <p className="text-slate-600 text-sm mt-0.5">
                     {profile.savedAddress.upazila}, {profile.savedAddress.district}, {profile.savedAddress.division}
                   </p>
                 </div>
               </div>
             ) : (
               <div className="text-center py-10 border-2 border-dashed border-slate-200 rounded-2xl bg-slate-50/50 max-w-lg">
                 <MapPin className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                 <p className="text-slate-500 font-medium text-sm mb-4">No saved address yet! Create one for faster checkout.</p>
                 <button 
                   onClick={() => setEditing(true)} 
                   className="inline-flex items-center gap-2 text-sm bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2 rounded-xl cursor-pointer transition-all active:scale-[97%] shadow-sm"
                 >
                   <Plus className="w-4 h-4" /> Add Saved Address
                 </button>
               </div>
             )}
          </div>
        )}
      </main>
      </div>
    </div>
  );
}
