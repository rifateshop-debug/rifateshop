import React, { useEffect, useState } from 'react';
import { Outlet, Link, useNavigate } from 'react-router-dom';
import { Search, ShoppingCart, User as UserIcon, ChevronDown, ShieldCheck, MapPin, Mail, Phone, Truck, Store, MessageCircle, Facebook, Clock } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { collection, onSnapshot } from 'firebase/firestore';
import { db } from '../../firebase';
import LiveChat from '../../components/LiveChat';
import AuthModal from '../../components/AuthModal';

export default function MainLayout() {
  const { user, signInWithGoogle, setAuthModalOpen } = useAuth();
  const { cart } = useCart();
  const navigate = useNavigate();
  const [logo, setLogo] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [insideDhaka, setInsideDhaka] = useState(70);
  const [outsideDhaka, setOutsideDhaka] = useState(130);
  const [currencySymbol, setCurrencySymbol] = useState('৳');

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'settings'), (snap) => {
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as any));
      const foundLogo = data.find(d => d.type === 'logo');
      if (foundLogo) {
        setLogo(foundLogo.url as string);
      } else {
        setLogo(null);
      }

      const foundConfig = data.find(d => d.id === 'shop_config');
      if (foundConfig) {
        setCurrencySymbol(foundConfig.currency || '৳');
        setInsideDhaka(Number(foundConfig.insideDhaka) ?? 70);
        setOutsideDhaka(Number(foundConfig.outsideDhaka) ?? 130);
      }
    });
    return () => unsub();
  }, []);

  const triggerLogin = () => {
    setAuthModalOpen(true);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/shop?q=${encodeURIComponent(searchQuery.trim())}`);
    } else {
      navigate(`/shop`);
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans bg-slate-50 text-slate-800">
      {/* Header */}
      <nav className="bg-white border-b h-16 flex items-center justify-between px-6 shrink-0 z-50">
        <div className="flex items-center gap-6">
          <Link to="/" className="flex-shrink-0 mr-2">
            {logo ? (
              <img src={logo} alt="Rifateshop Logo" className="h-14 object-contain" />
            ) : (
              <div className="h-14 px-4 bg-blue-600 rounded flex items-center justify-center text-white font-bold tracking-tighter">
                RIFATESHOP
              </div>
            )}
          </Link>

          <Link to="/shop" className="hidden sm:flex items-center gap-2 text-slate-700 hover:text-blue-600 transition-colors font-bold text-sm uppercase tracking-wider">
            <Store className="w-5 h-5" />
            Shop
          </Link>

          <form onSubmit={handleSearch} className="relative w-72 lg:w-96 hidden md:block">
            <input 
              type="text" 
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search products..." 
              className="w-full h-10 bg-slate-100 rounded-full px-4 text-sm border-none focus:ring-2 focus:ring-blue-500 outline-none"
            />
            <button type="submit" className="absolute right-3 top-2.5 text-slate-400 hover:text-blue-600 transition-colors">
              <Search className="w-5 h-5" />
            </button>
          </form>
        </div>

        <div className="flex items-center gap-6">
          <a href="tel:+8801967269143" className="hidden lg:flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-700 hover:bg-slate-200 hover:text-blue-600 rounded-full transition-colors font-bold text-sm">
            <Phone className="w-4 h-4" />
            Contact +880 1967269143
          </a>

          <button 
            onClick={() => window.dispatchEvent(new CustomEvent('open-customer-chat'))}
            className="flex items-center gap-2 px-4 py-2 bg-orange-100 text-orange-700 hover:bg-orange-200 hover:text-orange-900 rounded-full transition-colors font-bold text-sm cursor-pointer"
          >
            <MessageCircle className="w-4 h-4" />
            Live Chat
          </button>

          <Link to="/admin" className="relative p-2 text-slate-600 hover:bg-slate-50 rounded-full transition-colors cursor-pointer group" title="Admin Panel">
            <ShieldCheck className="w-6 h-6 group-hover:text-blue-600 transition-colors" />
          </Link>

          <Link to="/cart" className="relative p-2 text-slate-600 hover:bg-slate-50 rounded-full transition-colors cursor-pointer">
            <ShoppingCart className="w-6 h-6" />
            {cart.length > 0 && (
              <span className="absolute top-0 right-0 bg-red-500 text-white text-[10px] font-bold w-4 h-4 flex items-center justify-center rounded-full">
                {cart.length}
              </span>
            )}
          </Link>

          {user ? (
            <Link to="/account" className="flex items-center gap-2 px-3 py-1 bg-slate-100 rounded-full cursor-pointer hover:bg-slate-200 transition-colors">
              {user.photoURL ? (
                <img src={user.photoURL} alt="User" className="w-7 h-7 rounded-full" />
              ) : (
                <div className="w-7 h-7 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                  {user.displayName?.[0] || 'U'}
                </div>
              )}
              <span className="text-sm font-medium truncate max-w-[120px] hidden sm:block">{user.displayName || user.email}</span>
              <ChevronDown className="w-4 h-4 opacity-50 hidden sm:block" />
            </Link>
          ) : (
            <button 
              onClick={triggerLogin} 
              className="flex items-center gap-2 px-3 py-1 bg-slate-100 rounded-full cursor-pointer hover:bg-slate-200 transition-colors"
            >
              <UserIcon className="w-5 h-5 text-slate-600" />
              <span className="text-sm font-medium hidden sm:block">Login</span>
            </button>
          )}
        </div>
      </nav>

      {/* Main Display */}
      <main className="flex-1 overflow-auto bg-slate-50 flex flex-col">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-orange-500 border-t border-orange-600 text-white py-12 px-6 sm:px-12 shrink-0">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-8 justify-between items-start">
          <div className="flex-1 space-y-4">
            <h5 className="font-bold tracking-wide uppercase text-sm mb-4 border-b border-orange-400 pb-2">Contact Information</h5>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 shrink-0 mt-0.5" />
                <span className="text-sm leading-relaxed">Shyamoli, Dhaka, Bangladesh, 1207</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 shrink-0" />
                <a href="mailto:rifateshop@gmail.com" className="text-sm hover:text-orange-100 transition-colors">rifateshop@gmail.com</a>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 shrink-0" />
                <a href="tel:+8801967269143" className="text-sm hover:text-orange-100 transition-colors">+880 1967269143</a>
              </div>
              <div className="flex items-center gap-3">
                <MessageCircle className="w-5 h-5 shrink-0" />
                <a href="https://wa.me/8801967269143" target="_blank" rel="noreferrer" className="text-sm hover:text-orange-100 transition-colors">WhatsApp: +880 1967269143</a>
              </div>
              <a href="https://www.facebook.com/rifateshop25" target="_blank" rel="noreferrer" className="flex items-center gap-3 bg-white text-orange-600 px-3 py-2 rounded-lg w-fit hover:bg-slate-100 transition-colors mt-2 mb-2 shadow flex-shrink-0">
                <Facebook className="w-5 h-5 shrink-0" />
                <span className="text-sm font-bold">facebook.com/rifateshop25</span>
              </a>
              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 shrink-0 mt-0.5" />
                <span className="text-sm leading-relaxed">Everyday: 9:00 AM - 10:00 PM</span>
              </div>
            </div>
          </div>

          <div className="flex-1 space-y-4">
            <h5 className="font-bold tracking-wide uppercase text-sm mb-4 border-b border-orange-400 pb-2">About Us</h5>
            <p className="text-sm leading-relaxed text-orange-50">
              Welcome to RifateShop! We are committed to providing you with the best quality products at unbeatable prices. Your satisfaction is our first priority. Shop your daily essentials, gadgets, and exclusive deals with trust and confidence.
            </p>
          </div>

          <div className="flex-1 space-y-4 md:text-right flex flex-col md:items-end">
            <h5 className="font-bold tracking-wide uppercase text-sm mb-4">Shipping Policy</h5>
            <div className="bg-orange-600 p-4 rounded-xl border border-orange-400 inline-block text-left w-full sm:w-auto shadow-inner">
              <div className="flex items-center gap-3 border-b border-orange-500 pb-3 mb-3">
                <Truck className="w-5 h-5 text-indigo-100" />
                <div className="flex flex-col">
                  <span className="text-xs uppercase font-bold tracking-wider opacity-80">Inside Dhaka</span>
                  <span className="text-sm font-semibold">{currencySymbol}{insideDhaka}</span>
                </div>
              </div>
              <div className="flex items-center gap-3 border-b border-orange-500 pb-3 mb-3">
                <Truck className="w-5 h-5 text-indigo-100" />
                <div className="flex flex-col">
                  <span className="text-xs uppercase font-bold tracking-wider opacity-80">Outside Dhaka</span>
                  <span className="text-sm font-semibold">{currencySymbol}{outsideDhaka}</span>
                </div>
              </div>
              <div className="text-xs font-bold text-white tracking-wider flex items-center justify-center sm:justify-start gap-2 bg-orange-700/50 px-3 py-1.5 rounded">
                <ShieldCheck className="w-4 h-4" /> CASH ON DELIVERY AVAILABLE
              </div>
            </div>
          </div>
        </div>
        
        <div className="max-w-7xl mx-auto mt-12 pt-6 border-t border-orange-400 text-center text-xs opacity-80 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© {new Date().getFullYear()} RifateShop. All rights reserved.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:opacity-100 transition-opacity">Privacy Policy</a>
            <a href="#" className="hover:opacity-100 transition-opacity">Terms of Service</a>
          </div>
        </div>
      </footer>
      <LiveChat />
      <AuthModal />
    </div>
  );
}
