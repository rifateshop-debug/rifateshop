import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { db } from '../../firebase';
import { collection, addDoc, serverTimestamp, doc, getDoc } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import { Trash2, ArrowLeft, Home as HomeIcon, Briefcase } from 'lucide-react';
import { bangladeshData, divisionList, getDistricts, getUpazilas } from '../../data/bangladeshLocation';
import { sendOrderNotifications } from '../../utils/notifService';

export default function CartPage() {
  const { cart, removeFromCart, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [customerName, setCustomerName] = useState('');
  const [division, setDivision] = useState('');
  const [district, setDistrict] = useState('');
  const [upazila, setUpazila] = useState('');
  const [addressLine, setAddressLine] = useState('');
  const [phone, setPhone] = useState('');
  const [addressType, setAddressType] = useState('home'); // 'home' | 'office'
  const [paymentMethod, setPaymentMethod] = useState('cod');

  const [deliveryRates, setDeliveryRates] = useState({ insideDhaka: 70, outsideDhaka: 130, currency: '৳' });

  useEffect(() => {
    if (!user) return;
    const fetchSavedAddress = async () => {
      try {
        const userSnap = await getDoc(doc(db, 'users', user.uid));
        if (userSnap.exists()) {
          const data = userSnap.data();
          if (data.savedAddress) {
            setCustomerName(data.savedAddress.customerName || user.displayName || '');
            setDivision(data.savedAddress.division || '');
            setDistrict(data.savedAddress.district || '');
            setUpazila(data.savedAddress.upazila || '');
            setAddressLine(data.savedAddress.addressLine || '');
            setPhone(data.savedAddress.phone || '');
            setAddressType(data.savedAddress.addressType || 'home');
          } else if (user.displayName) {
            setCustomerName(user.displayName);
          }
        } else if (user.displayName) {
          setCustomerName(user.displayName);
        }
      } catch (err) {
        console.warn("Unable to preload saved address:", err);
      }
    };
    fetchSavedAddress();
  }, [user]);

  useEffect(() => {
    const fetchRates = async () => {
      try {
        const snap = await getDoc(doc(db, 'settings', 'shop_config'));
        if (snap.exists()) {
          const data = snap.data();
          setDeliveryRates({
            insideDhaka: Number(data.insideDhaka) || 70,
            outsideDhaka: Number(data.outsideDhaka) || 130,
            currency: data.currency || '৳'
          });
        }
      } catch (err) {
        console.warn("Unable to fetch shop config rates:", err);
      }
    };
    fetchRates();
  }, []);

  const subtotal = cart.reduce((acc, item) => acc + (Number(item.specialPrice || item.price) * item.quantity), 0);
  
  // Delivery Charge Logic: Inside vs Outside Dhaka dynamically fetched from Firebase
  const deliveryCharge = district.toLowerCase() === 'dhaka' ? deliveryRates.insideDhaka : deliveryRates.outsideDhaka;
  const total = subtotal + (cart.length > 0 ? deliveryCharge : 0);
  const currencySymbol = deliveryRates.currency;

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      alert('Please login to place an order.');
      navigate('/');
      return;
    }
    if (cart.length === 0) return;

    const docRef = await addDoc(collection(db, 'orders'), {
      userId: user.uid,
      customerEmail: user.email || '',
      items: cart,
      subtotal,
      deliveryCharge,
      total,
      paymentMethod,
      status: 'pending',
      address: {
        customerName,
        division,
        district,
        upazila,
        addressLine,
        phone,
        addressType
      },
      createdAt: serverTimestamp()
    });

    // Send Real-time persistent and simulation notifications to Phone and Email
    try {
      await sendOrderNotifications({
        orderId: docRef.id,
        userId: user.uid,
        customerName,
        phone,
        email: user.email || 'customer@rifateshop.com',
        status: 'pending'
      });
    } catch (notifErr) {
      console.warn("Notification dispatch failed but order was placed successfully:", notifErr);
    }

    clearCart();
    alert('Order placed successfully!');
    navigate('/account');
  };

  if (cart.length === 0) {
    return (
      <div className="p-12 text-center text-slate-500">
        <div className="mb-4">Your cart is empty.</div>
        <button onClick={() => navigate(-1)} className="inline-flex items-center text-blue-600 hover:text-blue-700 transition-colors font-medium">
          <ArrowLeft className="w-5 h-5 mr-2" />
          Go Back
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full flex flex-col md:flex-row gap-8 text-slate-800">
      <div className="w-full flex-1 md:hidden">
         <button onClick={() => navigate(-1)} className="flex items-center text-slate-500 hover:text-blue-600 transition-colors font-medium mb-4">
           <ArrowLeft className="w-5 h-5 mr-2" />
           Back
         </button>
      </div>
      {/* Cart Items */}
      <div className="flex-1 bg-white p-6 rounded-xl shadow-sm border border-slate-200">
        <div className="flex items-center gap-4 mb-6 border-b border-slate-100 pb-4">
           <button onClick={() => navigate(-1)} className="hidden md:flex items-center text-slate-500 hover:text-blue-600 transition-colors font-medium bg-slate-50 p-2 rounded-lg border border-slate-200">
             <ArrowLeft className="w-4 h-4" />
           </button>
          <h2 className="text-2xl font-bold text-slate-900">Shopping Cart</h2>
        </div>
        <div className="space-y-4">
          {cart.map((item) => (
            <div key={item.id} className="flex items-center space-x-4 border-b border-slate-100 pb-4">
              <img src={item.image} alt={item.title} className="w-16 h-16 object-contain rounded bg-slate-50 border p-1" />
              <div className="flex-1">
                <h4 className="font-semibold text-slate-900 line-clamp-1">{item.title}</h4>
                {item.specialPrice ? (
                  <p className="text-blue-600 font-bold">{currencySymbol}{item.specialPrice} <span className="text-xs text-slate-400 line-through">{currencySymbol}{item.price}</span></p>
                ) : (
                  <p className="text-blue-600 font-bold">{currencySymbol}{item.price}</p>
                )}
              </div>
              <button onClick={() => removeFromCart(item.id)} className="text-red-500 hover:bg-red-50 p-2 rounded">
                <Trash2 className="w-5 h-5"/>
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Checkout Sidebar */}
      <div className="w-full md:w-96 bg-white p-6 rounded-xl shadow-sm border border-slate-200 h-fit sticky top-24">
        <h3 className="text-xl font-bold mb-4 text-slate-900">Checkout Summary</h3>
        <div className="space-y-2 mb-6 text-sm text-slate-600">
          <div className="flex justify-between"><span>Subtotal:</span> <span className="font-bold text-slate-800">{currencySymbol}{subtotal}</span></div>
          <div className="flex justify-between">
            <span>Delivery 
               {district && <span className="text-xs text-blue-400 block">({district === 'Dhaka' ? 'Inside' : 'Outside'} Dhaka)</span>}
            </span> 
            <span className="font-bold text-slate-800">{currencySymbol}{deliveryCharge}</span>
          </div>
          <div className="flex justify-between font-bold text-lg text-blue-600 border-t border-slate-200 pt-2 mt-2">
            <span className="text-slate-900">Total:</span> <span>{currencySymbol}{total}</span>
          </div>
        </div>

        <form onSubmit={handleCheckout} className="space-y-4">
          <div className="flex justify-between items-center">
            <h4 className="font-semibold text-slate-800">Shipping Address</h4>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Select Tag</span>
          </div>

          <div className="grid grid-cols-2 gap-2 mb-1">
            <button
              type="button"
              onClick={() => setAddressType('home')}
              className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border font-bold text-xs cursor-pointer transition-all ${
                addressType === 'home' 
                  ? 'border-blue-600 bg-blue-50 text-blue-700 shadow-2xs' 
                  : 'border-slate-200 hover:border-slate-300 bg-slate-50 text-slate-600'
              }`}
            >
              <HomeIcon className="w-3.5 h-3.5" /> Home
            </button>
            <button
              type="button"
              onClick={() => setAddressType('office')}
              className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border font-bold text-xs cursor-pointer transition-all ${
                addressType === 'office' 
                  ? 'border-blue-600 bg-blue-50 text-blue-700 shadow-2xs' 
                  : 'border-slate-200 hover:border-slate-300 bg-slate-50 text-slate-600'
              }`}
            >
              <Briefcase className="w-3.5 h-3.5" /> Office
            </button>
          </div>

          <input 
            required 
            type="text" 
            placeholder="Your Name (আপনার নাম)" 
            value={customerName} 
            onChange={e => setCustomerName(e.target.value)} 
            className="w-full border border-slate-200 p-2 rounded text-sm bg-slate-50 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500" 
          />
          
          <select required value={division} onChange={e => {setDivision(e.target.value); setDistrict(''); setUpazila('');}} className="w-full border border-slate-200 p-2 rounded text-sm bg-slate-50 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500">
            <option value="">Select Division</option>
            {divisionList.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
          
          <select required value={district} disabled={!division} onChange={e => {setDistrict(e.target.value); setUpazila('');}} className="w-full border border-slate-200 p-2 rounded text-sm bg-slate-50 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 disabled:opacity-50">
            <option value="">Select District</option>
            {division && getDistricts(division).map(d => <option key={d} value={d}>{d}</option>)}
          </select>
          
          <select required value={upazila} disabled={!district} onChange={e => setUpazila(e.target.value)} className="w-full border border-slate-200 p-2 rounded text-sm bg-slate-50 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 disabled:opacity-50">
            <option value="">Select Upazila</option>
            {division && district && getUpazilas(division, district).map(u => <option key={u} value={u}>{u}</option>)}
          </select>
          <textarea required placeholder="Detailed Address (House, Road)" value={addressLine} onChange={e => setAddressLine(e.target.value)} rows={2} className="w-full border border-slate-200 p-2 rounded text-sm bg-slate-50 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"></textarea>
          <input required type="tel" placeholder="Phone Number" value={phone} onChange={e => setPhone(e.target.value)} className="w-full border border-slate-200 p-2 rounded text-sm bg-slate-50 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500" />
          
          <h4 className="font-semibold text-slate-800 mt-4">Payment Method</h4>
          <div className="flex items-center space-x-2 border border-blue-200 p-3 rounded bg-blue-50">
            <input type="radio" id="cod" name="payment" value="cod" checked={paymentMethod === 'cod'} onChange={e => setPaymentMethod(e.target.value)} className="accent-blue-600" />
            <label htmlFor="cod" className="text-sm font-bold text-blue-800 uppercase tracking-wide">Cash on Delivery</label>
          </div>

          <button type="submit" className="w-full bg-blue-600 text-white font-bold py-3 rounded-md hover:bg-blue-700 transition uppercase text-sm mt-4">
            Place Order
          </button>
        </form>
      </div>
    </div>
  );
}
