import React, { useEffect, useState } from 'react';
import { db } from '../../firebase';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { ShoppingCart } from 'lucide-react';
import { ProductCard } from './Home';

export default function ShopPage() {
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const { addToCart } = useCart();
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get('q')?.toLowerCase() || '';
  const categoryId = searchParams.get('category') || '';
  const categoryNameParam = searchParams.get('cname') || '';
  const navigate = useNavigate();

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'products'), (snap) => {
      const loadedProducts = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      // Client-side sort to avoid Firestore composite index requirement
      loadedProducts.sort((a: any, b: any) => {
        const dateA = a.createdAt?.seconds || a.createdAt ? new Date(a.createdAt?.seconds * 1000 || a.createdAt).getTime() : 0;
        const dateB = b.createdAt?.seconds || b.createdAt ? new Date(b.createdAt?.seconds * 1000 || b.createdAt).getTime() : 0;
        return dateB - dateA;
      });
      setProducts(loadedProducts);
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    const unsubCats = onSnapshot(collection(db, 'categories'), (snap) => {
      setCategories(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });
    return () => unsubCats();
  }, []);

  const getPageTitle = () => {
    if (searchQuery) {
      return `Search Results for "${searchQuery}"`;
    }
    if (categoryId) {
      if (categoryNameParam) return categoryNameParam;
      const found = categories.find(c => c.id === categoryId);
      return found ? found.name : 'Category Products';
    }
    return 'All Products';
  };

  const filteredProducts = products.filter(p => {
    const matchesSearch = !searchQuery || p.title.toLowerCase().includes(searchQuery);
    const matchesCategory = !categoryId || p.categoryId === categoryId;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="w-full flex-1 flex flex-col p-6 max-w-7xl mx-auto w-full">
      <div className="flex justify-between items-center mb-6 border-b border-slate-200 pb-4">
        <h1 className="text-2xl font-bold text-slate-800">
          {getPageTitle()}
        </h1>
        {categoryId && (
          <Link to="/shop" className="text-sm font-bold text-blue-600 hover:underline">
            View All Products
          </Link>
        )}
      </div>

      {filteredProducts.length === 0 ? (
        <div className="text-center py-12 text-slate-500">
          No products found in this category.
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {filteredProducts.map(product => (
            <ProductCard key={product.id} product={product} navigate={navigate} />
          ))}
        </div>
      )}
    </div>
  );
}
